/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ivory: {
          50: '#FDFBF7',
          100: '#FAF6F0',
          200: '#F5EEE3',
          300: '#EDE2D2',
          400: '#E2D3BE',
          500: '#D4C1A6',
        },
        blush: {
          50: '#FBF5F3',
          100: '#F5E8E4',
          200: '#EDD7D0',
          300: '#E1C2B9',
          400: '#D2A89D',
          500: '#BF8B7D',
          600: '#A66E60',
        },
        champagne: {
          50: '#FBF8F0',
          100: '#F5EEDC',
          200: '#EBDDC0',
          300: '#DDC89E',
          400: '#CCB07E',
          500: '#B8995A',
          600: '#9C7E45',
        },
        espresso: {
          700: '#4A3A33',
          800: '#3B2F2A',
          900: '#2A201C',
          950: '#1C1512',
        },
        gold: {
          400: '#D4B870',
          500: '#C9A961',
          600: '#B8995A',
          700: '#9A7E45',
        },
      },
      fontFamily: {
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['Jost', 'system-ui', 'sans-serif'],
      },
      letterSpacing: {
        widest: '0.25em',
      },
      maxWidth: {
        '8xl': '88rem',
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease-out forwards',
        'fade-up': 'fadeUp 0.7s ease-out forwards',
        'fade-down': 'fadeDown 0.6s ease-out forwards',
        'scale-in': 'scaleIn 0.4s ease-out forwards',
        'slide-in-right': 'slideInRight 0.4s ease-out forwards',
        'marquee': 'marquee 30s linear infinite',
        'count-bump': 'countBump 0.4s ease-out',
      },
      keyframes: {
        fadeIn: { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        fadeUp: { '0%': { opacity: '0', transform: 'translateY(24px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        fadeDown: { '0%': { opacity: '0', transform: 'translateY(-16px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        scaleIn: { '0%': { opacity: '0', transform: 'scale(0.96)' }, '100%': { opacity: '1', transform: 'scale(1)' } },
        slideInRight: { '0%': { transform: 'translateX(100%)' }, '100%': { transform: 'translateX(0)' } },
        marquee: { '0%': { transform: 'translateX(0)' }, '100%': { transform: 'translateX(-50%)' } },
        countBump: { '0%, 100%': { transform: 'scale(1)' }, '50%': { transform: 'scale(1.4)' } },
      },
    },
  },
  plugins: [],
};
