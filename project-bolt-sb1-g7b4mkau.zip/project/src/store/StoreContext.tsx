import { createContext, useContext, useEffect, useMemo, useState, useCallback, type ReactNode } from 'react';
import type { CartItem, Product } from '@/data/catalog';
import { PRODUCTS, COUPONS, SHIPPING_FEE, FREE_SHIPPING_THRESHOLD, type Coupon } from '@/data/catalog';

interface StoreState {
  cart: CartItem[];
  wishlist: string[];
  addToCart: (product: Product, shade: string | undefined, quantity: number) => void;
  removeFromCart: (productId: string, shade?: string) => void;
  updateQuantity: (productId: string, shade: string | undefined, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  subtotal: number;
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  coupon: Coupon | null;
  applyCoupon: (code: string) => { ok: boolean; message: string };
  removeCoupon: () => void;
  discount: number;
  shipping: number;
  total: number;
  toasts: { id: number; message: string }[];
  notify: (message: string) => void;
  dismissToast: (id: number) => void;
}

const StoreContext = createContext<StoreState | null>(null);

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(() => load('noviq-cart', []));
  const [wishlist, setWishlist] = useState<string[]>(() => load('noviq-wishlist', []));
  const [couponCode, setCouponCode] = useState<string | null>(() => load('noviq-coupon', null));
  const [toasts, setToasts] = useState<{ id: number; message: string }[]>([]);

  useEffect(() => { localStorage.setItem('noviq-cart', JSON.stringify(cart)); }, [cart]);
  useEffect(() => { localStorage.setItem('noviq-wishlist', JSON.stringify(wishlist)); }, [wishlist]);
  useEffect(() => { localStorage.setItem('noviq-coupon', JSON.stringify(couponCode)); }, [couponCode]);

  const notify = useCallback((message: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);
  const dismissToast = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);

  const addToCart = useCallback((product: Product, shade: string | undefined, quantity: number) => {
    setCart((prev) => {
      const key = (i: CartItem) => i.productId + '|' + (i.shade ?? '');
      const idx = prev.findIndex((i) => key(i) === product.id + '|' + (shade ?? ''));
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], quantity: next[idx].quantity + quantity };
        return next;
      }
      return [...prev, { productId: product.id, slug: product.slug, name: product.name, price: product.price, image: product.images[0], shade, quantity }];
    });
    notify(`${product.name} added to your bag`);
  }, [notify]);

  const removeFromCart = useCallback((productId: string, shade?: string) => {
    setCart((prev) => prev.filter((i) => !(i.productId === productId && (i.shade ?? '') === (shade ?? ''))));
  }, []);

  const updateQuantity = useCallback((productId: string, shade: string | undefined, quantity: number) => {
    if (quantity < 1) return;
    setCart((prev) => prev.map((i) =>
      i.productId === productId && (i.shade ?? '') === (shade ?? '') ? { ...i, quantity } : i
    ));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const toggleWishlist = useCallback((productId: string) => {
    setWishlist((prev) => {
      if (prev.includes(productId)) {
        notify('Removed from wishlist');
        return prev.filter((id) => id !== productId);
      }
      notify('Saved to wishlist');
      return [...prev, productId];
    });
  }, [notify]);

  const isWishlisted = useCallback((productId: string) => wishlist.includes(productId), [wishlist]);

  const applyCoupon = useCallback((code: string) => {
    const found = COUPONS.find((c) => c.code.toLowerCase() === code.trim().toLowerCase());
    if (!found) return { ok: false, message: 'That code is not valid.' };
    setCouponCode(found.code);
    notify(`Code ${found.code} applied`);
    return { ok: true, message: found.label };
  }, [notify]);

  const removeCoupon = useCallback(() => setCouponCode(null), []);

  const cartCount = useMemo(() => cart.reduce((s, i) => s + i.quantity, 0), [cart]);
  const subtotal = useMemo(() => cart.reduce((s, i) => s + i.price * i.quantity, 0), [cart]);

  const coupon = useMemo(() => COUPONS.find((c) => c.code === couponCode) ?? null, [couponCode]);
  const discount = useMemo(() => {
    if (!coupon) return 0;
    return coupon.type === 'percent' ? Math.round(subtotal * coupon.value) / 100 : coupon.value;
  }, [coupon, subtotal]);
  const shipping = useMemo(() => {
    if (subtotal === 0) return 0;
    if (subtotal - discount >= FREE_SHIPPING_THRESHOLD) return 0;
    return SHIPPING_FEE;
  }, [subtotal, discount]);
  const total = Math.max(0, subtotal - discount + shipping);

  const value: StoreState = {
    cart, wishlist, addToCart, removeFromCart, updateQuantity, clearCart, cartCount, subtotal,
    toggleWishlist, isWishlisted, coupon, applyCoupon, removeCoupon, discount, shipping, total,
    toasts, notify, dismissToast,
  };
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}

export function formatPKR(n: number): string {
  return 'Rs. ' + n.toLocaleString('en-PK');
}
