import { StoreProvider } from '@/store/StoreContext';
import { useRouter } from '@/router';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Toasts } from '@/components/Toasts';
import { HomePage } from '@/pages/HomePage';
import { ShopPage } from '@/pages/ShopPage';
import { ProductPage } from '@/pages/ProductPage';
import { CartPage } from '@/pages/CartPage';
import { CheckoutPage } from '@/pages/CheckoutPage';
import { WishlistPage } from '@/pages/WishlistPage';
import { SearchPage } from '@/pages/SearchPage';
import { CollectionsPage, CollectionDetailPage } from '@/pages/CollectionsPage';
import { AboutPage } from '@/pages/AboutPage';
import { ContactPage } from '@/pages/ContactPage';
import { FaqPage } from '@/pages/FaqPage';
import { ShippingPage, ReturnsPage } from '@/pages/PolicyPages';
import { PrivacyPage, TermsPage } from '@/pages/LegalPages';
import { JournalListPage, JournalPostPage } from '@/pages/JournalPages';
import { AccountPage } from '@/pages/AccountPage';
import { NotFoundPage } from '@/pages/NotFoundPage';

function Router() {
  const { route } = useRouter();
  const { path } = route;
  const parts = path.split('/').filter(Boolean);

  if (path === '/' || path === '') return <HomePage />;
  if (path === '/shop') return <ShopPage />;
  if (path === '/cart') return <CartPage />;
  if (path === '/checkout') return <CheckoutPage />;
  if (path === '/wishlist') return <WishlistPage />;
  if (path === '/search') return <SearchPage />;
  if (path === '/collections') return <CollectionsPage />;
  if (path === '/collections/all') return <CollectionsPage />;
  if (parts[0] === 'collections' && parts[1]) return <CollectionDetailPage id={parts[1]} />;
  if (path === '/about') return <AboutPage />;
  if (path === '/contact') return <ContactPage />;
  if (path === '/faq') return <FaqPage />;
  if (path === '/shipping') return <ShippingPage />;
  if (path === '/returns') return <ReturnsPage />;
  if (path === '/privacy') return <PrivacyPage />;
  if (path === '/terms') return <TermsPage />;
  if (path === '/account') return <AccountPage />;
  if (path === '/journal') return <JournalListPage />;
  if (parts[0] === 'journal' && parts[1]) return <JournalPostPage slug={parts[1]} />;
  if (parts[0] === 'product' && parts[1]) return <ProductPage slug={parts[1]} />;

  return <NotFoundPage />;
}

export default function App() {
  return (
    <StoreProvider>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          <Router />
        </main>
        <Footer />
        <Toasts />
      </div>
    </StoreProvider>
  );
}
