import { useMemo, useState, useEffect } from 'react';
import { SlidersHorizontal, Grid3x3, List, X, Check } from 'lucide-react';
import { ProductCard } from '@/components/ProductCard';
import { Reveal, StarRating, Price } from '@/components/ui';
import { Link, useRouter } from '@/router';
import {
  PRODUCTS, CATEGORIES, ALL_SHADES, ALL_SKIN_TYPES, PRICE_MIN, PRICE_MAX,
} from '@/data/catalog';

type SortKey = 'featured' | 'price-asc' | 'price-desc' | 'newest' | 'bestsellers';

export function ShopPage() {
  const { route, navigate } = useRouter();
  const initial = route.query;

  const [category, setCategory] = useState<string>(initial.category ?? 'all');
  const [priceMax, setPriceMax] = useState<number>(PRICE_MAX);
  const [shades, setShades] = useState<string[]>([]);
  const [skinTypes, setSkinTypes] = useState<string[]>([]);
  const [minRating, setMinRating] = useState<number>(0);
  const [sort, setSort] = useState<SortKey>((initial.sort as SortKey) ?? 'featured');
  const [search, setSearch] = useState<string>(initial.q ?? '');
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const [visible, setVisible] = useState(8);
  const [filtersOpen, setFiltersOpen] = useState(false);

  useEffect(() => {
    setCategory(initial.category ?? 'all');
    setSort((initial.sort as SortKey) ?? 'featured');
    setSearch(initial.q ?? '');
  }, [initial.category, initial.sort, initial.q]);

  const toggle = <T,>(arr: T[], set: (v: T[]) => void, val: T) =>
    set(arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val]);

  const filtered = useMemo(() => {
    let list = [...PRODUCTS];
    if (category !== 'all') {
      const catName = CATEGORIES.find((c) => c.slug === category)?.name;
      if (catName) list = list.filter((p) => p.category === catName);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((p) =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.collection.toLowerCase().includes(q) ||
        p.shortDesc.toLowerCase().includes(q)
      );
    }
    list = list.filter((p) => p.price <= priceMax);
    if (shades.length) {
      list = list.filter((p) => p.shades?.some((s) => shades.includes(s.name)));
    }
    if (skinTypes.length) {
      list = list.filter((p) => p.skinTypes?.some((s) => skinTypes.includes(s)));
    }
    if (minRating > 0) list = list.filter((p) => p.rating >= minRating);

    switch (sort) {
      case 'price-asc': list.sort((a, b) => a.price - b.price); break;
      case 'price-desc': list.sort((a, b) => b.price - a.price); break;
      case 'newest': list.sort((a, b) => Number(!!b.isNew) - Number(!!a.isNew)); break;
      case 'bestsellers': list.sort((a, b) => Number(!!b.bestseller) - Number(!!a.bestseller)); break;
    }
    return list;
  }, [category, search, priceMax, shades, skinTypes, minRating, sort]);

  const shown = filtered.slice(0, visible);
  const activeCount = (category !== 'all' ? 1 : 0) + shades.length + skinTypes.length + (minRating > 0 ? 1 : 0) + (priceMax < PRICE_MAX ? 1 : 0);

  const clearAll = () => {
    setCategory('all'); setPriceMax(PRICE_MAX); setShades([]); setSkinTypes([]); setMinRating(0);
    navigate('/shop');
  };

  const Filters = () => (
    <div className="space-y-8">
      {/* Category */}
      <div>
        <h3 className="field-label">Category</h3>
        <div className="flex flex-col gap-2.5">
          {[{ name: 'All', slug: 'all' }, ...CATEGORIES].map((c) => (
            <button
              key={c.slug}
              onClick={() => setCategory(c.slug)}
              className="flex items-center justify-between text-sm text-left text-espresso-900 hover:text-gold-600 transition-colors"
            >
              <span className={category === c.slug ? 'font-medium' : ''}>{c.name}</span>
              {category === c.slug && <Check size={15} className="text-gold-600" />}
            </button>
          ))}
        </div>
      </div>

      {/* Price */}
      <div>
        <h3 className="field-label">Max Price — Rs. {priceMax.toLocaleString('en-PK')}</h3>
        <input
          type="range" min={PRICE_MIN} max={PRICE_MAX} step={100}
          value={priceMax}
          onChange={(e) => setPriceMax(Number(e.target.value))}
          className="w-full accent-espresso-900"
        />
        <div className="flex justify-between text-xs text-espresso-700/50 mt-1">
          <span>Rs. {PRICE_MIN.toLocaleString('en-PK')}</span>
          <span>Rs. {PRICE_MAX.toLocaleString('en-PK')}</span>
        </div>
      </div>

      {/* Rating */}
      <div>
        <h3 className="field-label">Minimum Rating</h3>
        <div className="flex flex-col gap-2">
          {[0, 4, 4.5].map((r) => (
            <button key={r} onClick={() => setMinRating(r)} className="flex items-center gap-2 text-sm">
              <span className={`w-4 h-4 rounded-full border ${minRating === r ? 'border-espresso-900 bg-espresso-900' : 'border-ivory-400'}`} />
              {r === 0 ? 'All ratings' : <StarRating rating={r} count={0} />}
            </button>
          ))}
        </div>
      </div>

      {/* Shades */}
      <div>
        <h3 className="field-label">Shade</h3>
        <div className="flex flex-wrap gap-2">
          {ALL_SHADES.map((s) => (
            <button
              key={s}
              onClick={() => toggle(shades, setShades, s)}
              className={`text-xs px-3 py-1.5 border transition-colors ${shades.includes(s) ? 'bg-espresso-900 text-ivory-50 border-espresso-900' : 'border-ivory-300 text-espresso-700 hover:border-espresso-900'}`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Skin type */}
      <div>
        <h3 className="field-label">Skin Type</h3>
        <div className="flex flex-wrap gap-2">
          {ALL_SKIN_TYPES.map((s) => (
            <button
              key={s}
              onClick={() => toggle(skinTypes, setSkinTypes, s)}
              className={`text-xs px-3 py-1.5 border transition-colors ${skinTypes.includes(s) ? 'bg-espresso-900 text-ivory-50 border-espresso-900' : 'border-ivory-300 text-espresso-700 hover:border-espresso-900'}`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {activeCount > 0 && (
        <button onClick={clearAll} className="text-xs tracking-[0.15em] uppercase text-blush-600 hover:text-blush-700 flex items-center gap-1.5">
          <X size={13} /> Clear all filters
        </button>
      )}
    </div>
  );

  return (
    <div className="container-page py-10 lg:py-14">
      {/* Header */}
      <Reveal>
        <div className="mb-8">
          <p className="eyebrow mb-2">The Shop</p>
          <h1 className="font-serif text-4xl md:text-5xl text-espresso-900">
            {category === 'all' ? 'All Products' : CATEGORIES.find((c) => c.slug === category)?.name}
          </h1>
          <p className="text-sm text-espresso-700/70 mt-2">{filtered.length} products{search && ` for "${search}"`}</p>
        </div>
      </Reveal>

      {/* Search + sort bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8 pb-4 border-b border-ivory-200">
        <div className="flex items-center gap-3 w-full lg:max-w-xs">
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setVisible(8); }}
            placeholder="Search products…"
            className="flex-1 field-input py-2.5"
          />
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setFiltersOpen(true)}
            className="lg:hidden inline-flex items-center gap-2 text-xs tracking-[0.15em] uppercase border border-ivory-300 px-4 py-2.5"
          >
            <SlidersHorizontal size={14} /> Filters {activeCount > 0 && `(${activeCount})`}
          </button>
          <div className="flex items-center gap-2">
            <span className="text-[0.65rem] tracking-[0.2em] uppercase text-espresso-700/60 hidden sm:block">Sort</span>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortKey)}
              className="text-sm bg-ivory-50 border border-ivory-300 px-3 py-2.5 focus:outline-none focus:border-gold-500"
            >
              <option value="featured">Featured</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="newest">Newest</option>
              <option value="bestsellers">Bestsellers</option>
            </select>
          </div>
          <div className="hidden sm:flex items-center border border-ivory-300">
            <button onClick={() => setView('grid')} aria-label="Grid view" className={`p-2.5 ${view === 'grid' ? 'bg-espresso-900 text-ivory-50' : 'text-espresso-700'}`}><Grid3x3 size={16} /></button>
            <button onClick={() => setView('list')} aria-label="List view" className={`p-2.5 ${view === 'list' ? 'bg-espresso-900 text-ivory-50' : 'text-espresso-700'}`}><List size={16} /></button>
          </div>
        </div>
      </div>

      <div className="flex gap-10">
        {/* Sidebar */}
        <aside className="hidden lg:block w-60 shrink-0">
          <div className="sticky top-32">
            <Filters />
          </div>
        </aside>

        {/* Products */}
        <div className="flex-1 min-w-0">
          {shown.length === 0 ? (
            <div className="text-center py-24">
              <p className="font-serif text-2xl text-espresso-900 mb-3">No products found</p>
              <p className="text-sm text-espresso-700/70 mb-6">Try adjusting your filters or search terms.</p>
              <button onClick={clearAll} className="btn-secondary">Clear filters</button>
            </div>
          ) : view === 'grid' ? (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-5 gap-y-10">
              {shown.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
            </div>
          ) : (
            <div className="flex flex-col divide-y divide-ivory-200">
              {shown.map((p) => (
                <div key={p.id} className="py-6 flex gap-5">
                  <Link to={`/product/${p.slug}`} className="shrink-0">
                    <div className="img-zoom w-28 sm:w-36 aspect-[3/4] rounded-sm overflow-hidden bg-ivory-100">
                      <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" />
                    </div>
                  </Link>
                  <div className="flex-1 flex flex-col justify-center">
                    <p className="text-[0.65rem] tracking-[0.2em] uppercase text-espresso-700/60">{p.collection}</p>
                    <Link to={`/product/${p.slug}`} className="font-serif text-lg text-espresso-900 hover:text-gold-600">{p.name}</Link>
                    <StarRating rating={p.rating} count={p.reviewCount} />
                    <p className="text-sm text-espresso-700/70 mt-1.5 line-clamp-2 max-w-xl">{p.shortDesc}</p>
                    <Price price={p.price} originalPrice={p.originalPrice} className="text-espresso-900 font-medium mt-2" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {visible < filtered.length && (
            <div className="text-center mt-14">
              <button onClick={() => setVisible((v) => v + 8)} className="btn-secondary">
                Load More ({filtered.length - visible} remaining)
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile filter drawer */}
      {filtersOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-espresso-950/40 backdrop-blur-sm" onClick={() => setFiltersOpen(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-[85%] max-w-sm bg-ivory-50 p-6 overflow-y-auto animate-slide-in-right">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-serif text-2xl text-espresso-900">Filters</h2>
              <button onClick={() => setFiltersOpen(false)} aria-label="Close filters"><X size={22} /></button>
            </div>
            <Filters />
            <button onClick={() => setFiltersOpen(false)} className="btn-primary w-full mt-8">Show {filtered.length} results</button>
          </div>
        </div>
      )}
    </div>
  );
}
