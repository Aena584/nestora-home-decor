import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { Link } from '@/router';
import { Reveal } from '@/components/ui';

const FAQS = [
  {
    cat: 'Orders & Delivery',
    items: [
      { q: 'How long does delivery take?', a: 'Orders within major cities in Pakistan are typically delivered within 2–4 business days. Remote areas may take up to 6 business days. You will receive a tracking link via email once your order is dispatched.' },
      { q: 'Do you offer free shipping?', a: 'Yes. Shipping is free on all orders over Rs. 7,500. A flat shipping fee of Rs. 250 applies to orders below that amount.' },
      { q: 'Can I track my order?', a: 'Once your order is dispatched, you will receive an email with a tracking link. You can also reach out to our care team at care@noviq.cosmetics with your order number.' },
      { q: 'Which cities do you deliver to?', a: 'We deliver across Pakistan. If you are unsure whether your area is covered, please contact us before placing your order.' },
    ],
  },
  {
    cat: 'Returns & Exchanges',
    items: [
      { q: 'What is your return policy?', a: 'Unopened and unused products in their original packaging can be returned within 7 days of delivery. Please see our Returns & Refunds page for full details.' },
      { q: 'Can I return a used product?', a: 'For hygiene reasons, we are unable to accept returns of used makeup or skincare products unless the item arrived damaged or defective.' },
      { q: 'How do I start a return?', a: 'Email care@noviq.cosmetics with your order number and the reason for return. Our team will guide you through the process.' },
    ],
  },
  {
    cat: 'Products',
    items: [
      { q: 'Are your products cruelty-free?', a: 'We aim to partner with brands and products that are cruelty-free. Please check individual product details for specific claims, and contact us if you would like more information.' },
      { q: 'How do I find the right shade?', a: 'Each product page lists available shades with color references. If you are unsure, our care team can help you choose based on your undertone and preferences.' },
      { q: 'Are your products suitable for sensitive skin?', a: 'Many of our skincare products are formulated for sensitive skin. Check the skin-type filter on the shop page and review the ingredients list. We recommend a patch test for new products.' },
    ],
  },
  {
    cat: 'Payment',
    items: [
      { q: 'What payment methods do you accept?', a: 'We accept Cash on Delivery across Pakistan. Card payment is shown as an option in this demo, but no real card details are collected or processed.' },
      { q: 'Is Cash on Delivery available everywhere?', a: 'Cash on Delivery is available in most areas. In some remote locations, advance payment may be required. You will be notified at checkout if COD is unavailable for your address.' },
    ],
  },
];

export function FaqPage() {
  const [open, setOpen] = useState<string | null>(`${FAQS[0].cat}-0`);

  return (
    <div className="container-page py-10 lg:py-14 max-w-3xl">
      <Reveal>
        <div className="text-center mb-12">
          <p className="eyebrow mb-3">Help center</p>
          <h1 className="font-serif text-4xl md:text-5xl text-espresso-900">Frequently Asked Questions</h1>
        </div>
      </Reveal>

      <div className="space-y-10">
        {FAQS.map((group) => (
          <Reveal key={group.cat}>
            <h2 className="font-serif text-2xl text-espresso-900 mb-4">{group.cat}</h2>
            <div className="border-y border-ivory-200 divide-y divide-ivory-200">
              {group.items.map((item, i) => {
                const key = `${group.cat}-${i}`;
                const isOpen = open === key;
                return (
                  <div key={key}>
                    <button
                      onClick={() => setOpen(isOpen ? null : key)}
                      className="w-full flex items-center justify-between gap-4 py-4 text-left"
                      aria-expanded={isOpen}
                    >
                      <span className="text-sm font-medium text-espresso-900">{item.q}</span>
                      <ChevronDown size={18} className={`shrink-0 text-espresso-700/60 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {isOpen && (
                      <p className="pb-4 text-sm text-espresso-700/75 leading-relaxed animate-fade-down">{item.a}</p>
                    )}
                  </div>
                );
              })}
            </div>
          </Reveal>
        ))}
      </div>

      <div className="text-center mt-14 bg-ivory-100 p-8 rounded-sm">
        <h3 className="font-serif text-2xl text-espresso-900 mb-2">Still have a question?</h3>
        <p className="text-sm text-espresso-700/70 mb-5">Our care team is happy to help.</p>
        <Link to="/contact" className="btn-secondary">Contact Us</Link>
      </div>
    </div>
  );
}
