import { Link } from '@/router';
import { Reveal } from '@/components/ui';
import { ArrowRight } from 'lucide-react';

export function AboutPage() {
  return (
    <div>
      {/* Hero */}
      <section className="relative h-[56vh] min-h-[420px] overflow-hidden bg-espresso-950">
        <img
          src="https://images.pexels.com/photos/39525266/pexels-photo-39525266.jpeg?auto=compress&cs=tinysrgb&h=1000&w=1920"
          alt="NOVIQ brand story"
          className="absolute inset-0 w-full h-full object-cover opacity-65"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-espresso-950/80 via-espresso-950/20 to-transparent" />
        <div className="relative container-page h-full flex flex-col justify-center text-center max-w-3xl mx-auto items-center">
          <p className="eyebrow text-gold-400 mb-4">Our Story</p>
          <h1 className="font-serif text-4xl md:text-6xl text-ivory-50 leading-[1.08] text-balance">
            Beauty Is Personal. Make It Yours.
          </h1>
        </div>
      </section>

      {/* Philosophy */}
      <section className="container-page py-20 max-w-3xl mx-auto">
        <Reveal>
          <p className="eyebrow mb-4">Our Philosophy</p>
          <h2 className="font-serif text-3xl md:text-4xl text-espresso-900 mb-6">Beauty as self-expression, not instruction.</h2>
          <div className="space-y-5 text-espresso-700/85 leading-relaxed text-lg">
            <p>
              NOVIQ began with a simple idea: that beauty products should feel like an extension of the person using them — not a set of rules to follow or a standard to chase. We curate makeup and skincare that help you arrive at a version of yourself you already recognize, only more so.
            </p>
            <p>
              We are not interested in excess. We believe a thoughtful few, chosen well and used often, outperform a drawer full of impulse buys. Every product in our edit earns its place by how it performs, how it feels, and how it fits into a real morning — not a fantasy one.
            </p>
            <p>
              Confidence is not loud. It is quiet, deliberate, and built one small ritual at a time. That is the version of beauty we are here for.
            </p>
          </div>
        </Reveal>
      </section>

      {/* Three pillars */}
      <section className="bg-ivory-100 py-20 bg-grain">
        <div className="container-page grid md:grid-cols-3 gap-10">
          {[
            { n: '01', t: 'Self-Expression', d: 'We curate shades, finishes, and textures that adapt to you — not the other way around. Your look should belong to you alone.' },
            { n: '02', t: 'The Ritual', d: 'Beauty is a few deliberate minutes each day. We design products that make those minutes feel considered, unhurried, and entirely yours.' },
            { n: '03', t: 'Considered Choices', d: 'A refined edit of essentials, not an endless shelf. Each product is selected for how it performs in a real, lived-in routine.' },
          ].map((p, i) => (
            <Reveal key={p.n} delay={i * 100}>
              <div className="text-center md:text-left">
                <span className="font-serif text-5xl text-gold-500/40">{p.n}</span>
                <h3 className="font-serif text-2xl text-espresso-900 mt-2 mb-3">{p.t}</h3>
                <p className="text-espresso-700/75 leading-relaxed">{p.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Editorial band */}
      <section className="relative py-24 bg-espresso-950 overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img src="https://images.pexels.com/photos/7011222/pexels-photo-7011222.jpeg?auto=compress&cs=tinysrgb&h=900&w=1600" alt="" aria-hidden className="w-full h-full object-cover" />
        </div>
        <div className="relative container-page grid lg:grid-cols-2 gap-12 items-center">
          <Reveal>
            <img src="https://images.pexels.com/photos/4672661/pexels-photo-4672661.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="The NOVIQ experience" className="rounded-sm w-full aspect-[4/3] object-cover" loading="lazy" />
          </Reveal>
          <Reveal delay={120}>
            <p className="eyebrow text-gold-400 mb-4">The Customer Experience</p>
            <h2 className="font-serif text-3xl md:text-4xl text-ivory-50 mb-5 text-balance">
              From discovery to doorstep — a considered journey.
            </h2>
            <p className="text-ivory-200/80 leading-relaxed mb-6">
              We want every touchpoint to feel intentional: a site that helps you find what suits you, packaging that feels like a small gift to yourself, and delivery that respects your time. We are a young brand learning as we grow, and we listen carefully to the people who wear our products.
            </p>
            <Link to="/shop" className="inline-flex items-center gap-2 text-gold-400 text-xs tracking-[0.2em] uppercase border-b border-gold-400 pb-1 hover:gap-3 transition-all">
              Explore the collection <ArrowRight size={14} />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* Values note */}
      <section className="container-page py-20 max-w-2xl mx-auto text-center">
        <Reveal>
          <p className="eyebrow mb-4">An honest note</p>
          <p className="text-espresso-700/80 leading-relaxed text-lg">
            We are a growing brand and we are transparent about that. We do not make claims about manufacturing origins, ingredient sourcing, sustainability credentials, or testing practices that we cannot stand behind. What we can promise is that we will tell you what we know, and tell you when we do not yet know.
          </p>
        </Reveal>
      </section>
    </div>
  );
}
