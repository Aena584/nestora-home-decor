import { Reveal } from '@/components/ui';
import { Link } from '@/router';
import { ArrowRight } from 'lucide-react';

export function PrivacyPage() {
  const sections = [
    { t: 'Information We Collect', d: 'We collect information you provide directly, such as your name, email, phone number, and shipping address when you place an order or contact us. We also collect limited usage data to improve our site.' },
    { t: 'How We Use Your Information', d: 'We use your information to process orders, provide customer support, send order updates, and — only if you have opted in — share news about new products and offers.' },
    { t: 'Order & Payment Data', d: 'This is a demo store. We do not collect or store real card payment details. For Cash on Delivery orders, we only retain your contact and shipping information to fulfill the order.' },
    { t: 'Cookies & Local Storage', d: 'This demo uses your browser\'s local storage to remember your shopping bag and wishlist between visits. No personal data is sent to third parties for this purpose.' },
    { t: 'Sharing Your Information', d: 'We do not sell your personal information. We share data only with the service providers necessary to operate the store (for example, a delivery courier) and only to the extent needed to fulfill your order.' },
    { t: 'Your Rights', d: 'You may request access to, correction of, or deletion of your personal information at any time by contacting us. You can also clear your local storage data from your browser settings.' },
    { t: 'Data Retention', d: 'In this demo, your cart and wishlist data are stored only in your browser. We do not retain order data on a server in this prototype.' },
    { t: 'Changes to This Policy', d: 'We may update this policy as the store evolves. Any changes will be reflected on this page with an updated date.' },
    { t: 'Contact', d: 'Questions about your privacy? Email care@noviq.cosmetics and we will be happy to help.' },
  ];

  return (
    <div className="container-page py-10 lg:py-14 max-w-3xl">
      <Reveal>
        <div className="mb-10">
          <p className="eyebrow mb-3">Legal</p>
          <h1 className="font-serif text-4xl md:text-5xl text-espresso-900">Privacy Policy</h1>
          <p className="text-sm text-espresso-700/60 mt-3">Last updated: October 2026</p>
        </div>
      </Reveal>
      <Reveal>
        <div className="space-y-6">
          {sections.map((s) => (
            <section key={s.t}>
              <h2 className="font-serif text-xl text-espresso-900 mb-2">{s.t}</h2>
              <p className="text-espresso-700/80 leading-relaxed text-sm">{s.d}</p>
            </section>
          ))}
        </div>
      </Reveal>
    </div>
  );
}

export function TermsPage() {
  const sections = [
    { t: 'Acceptance of Terms', d: 'By accessing and using this website, you accept and agree to be bound by these Terms and Conditions. If you do not agree, please do not use the site.' },
    { t: 'This Is a Demo Store', d: 'NOVIQ Cosmetics in this environment is a demonstration prototype. Product listings, prices, and checkout are for display purposes. No real orders are fulfilled and no real payments are processed. Do not enter real payment card details.' },
    { t: 'Products & Pricing', d: 'We strive to display products and prices accurately. If an error occurs, we reserve the right to correct it and, where an order has already been placed in error, to cancel the order and offer a full refund.' },
    { t: 'Orders', d: 'Placing an order constitutes an offer to purchase. We may decline an order for any legitimate reason, including stock unavailability, suspected fraud, or pricing errors. Order confirmation does not guarantee fulfillment.' },
    { t: 'Returns', d: 'Please refer to our Returns & Refunds policy for the conditions and process for returning products.' },
    { t: 'Intellectual Property', d: 'All content on this site — including text, graphics, logos, and imagery — is owned by or licensed to NOVIQ Cosmetics and may not be reproduced without permission. Product photography is sourced from licensed stock providers.' },
    { t: 'Limitation of Liability', d: 'To the fullest extent permitted by law, NOVIQ Cosmetics is not liable for any indirect, incidental, or consequential damages arising from the use of this site or its products.' },
    { t: 'Changes to Terms', d: 'We may update these terms at any time. Continued use of the site after changes are posted constitutes acceptance of the revised terms.' },
    { t: 'Contact', d: 'Questions about these terms? Email care@noviq.cosmetics.' },
  ];

  return (
    <div className="container-page py-10 lg:py-14 max-w-3xl">
      <Reveal>
        <div className="mb-10">
          <p className="eyebrow mb-3">Legal</p>
          <h1 className="font-serif text-4xl md:text-5xl text-espresso-900">Terms & Conditions</h1>
          <p className="text-sm text-espresso-700/60 mt-3">Last updated: October 2026</p>
        </div>
      </Reveal>
      <Reveal>
        <div className="space-y-6">
          {sections.map((s) => (
            <section key={s.t}>
              <h2 className="font-serif text-xl text-espresso-900 mb-2">{s.t}</h2>
              <p className="text-espresso-700/80 leading-relaxed text-sm">{s.d}</p>
            </section>
          ))}
        </div>
      </Reveal>
      <div className="mt-12 text-center">
        <Link to="/contact" className="inline-flex items-center gap-2 text-gold-600 text-xs tracking-[0.2em] uppercase border-b border-gold-500 pb-1 hover:gap-3 transition-all">
          Questions about our terms? <ArrowRight size={13} />
        </Link>
      </div>
    </div>
  );
}
