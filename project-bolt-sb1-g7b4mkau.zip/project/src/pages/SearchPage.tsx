import { useEffect, useState } from 'react';
import { Search as SearchIcon } from 'lucide-react';
import { useRouter, Link } from '@/router';
import { PRODUCTS } from '@/data/catalog';
import { ProductCard } from '@/components/ProductCard';

export function SearchPage() {
  const { route, navigate } = useRouter();
  const [q, setQ] = useState(route.query.q ?? '');

  useEffect(() => {
    setQ(route.query.q ?? '');
  }, [route.query.q]);

  const results = q.trim()
    ? PRODUCTS.filter((p) => {
        const s = q.toLowerCase();
        return (
          p.name.toLowerCase().includes(s) ||
          p.category.toLowerCase().includes(s) ||
          p.collection.toLowerCase().includes(s) ||
          p.shortDesc.toLowerCase().includes(s)
        );
      })
    : [];

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/search?q=${encodeURIComponent(q.trim())}`);
  };

  return (
    <div className="container-page py-10 lg:py-14">
      <p className="eyebrow mb-2">Find your match</p>
      <h1 className="font-serif text-4xl md:text-5xl text-espresso-900 mb-6">Search</h1>

      <form onSubmit={submit} className="flex items-center gap-3 max-w-2xl border-b border-ivory-300 pb-3 mb-10">
        <SearchIcon size={20} className="text-espresso-700/60" />
        <input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search for products, categories, collections…"
          className="flex-1 bg-transparent outline-none text-lg text-espresso-900 placeholder:text-espresso-700/40 font-serif"
        />
        <button type="submit" className="text-xs tracking-[0.2em] uppercase text-gold-600 font-medium">Search</button>
      </form>

      {q.trim() === '' ? (
        <p className="text-sm text-espresso-700/60">Start typing to search across our catalog.</p>
      ) : results.length === 0 ? (
        <div className="text-center py-16">
          <p className="font-serif text-2xl text-espresso-900 mb-2">No results for "{q}"</p>
          <p className="text-sm text-espresso-700/70 mb-6">Try a different keyword, or browse our shop.</p>
          <Link to="/shop" className="btn-secondary">Browse all products</Link>
        </div>
      ) : (
        <>
          <p className="text-sm text-espresso-700/70 mb-6">{results.length} result{results.length !== 1 && 's'} for "{q}"</p>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-10">
            {results.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
          </div>
        </>
      )}
    </div>
  );
}
