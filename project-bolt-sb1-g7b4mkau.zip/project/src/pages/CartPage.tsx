import { useState } from 'react';
import { Minus, Plus, X, ShoppingBag, Tag, ArrowRight, ArrowLeft } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { useStore, formatPKR } from '@/store/StoreContext';
import { COUPONS, FREE_SHIPPING_THRESHOLD, SHIPPING_FEE } from '@/data/catalog';

export function CartPage() {
  const {
    cart, removeFromCart, updateQuantity, subtotal, shipping, total, discount, coupon,
    applyCoupon, removeCoupon, clearCart,
  } = useStore();
  const { navigate } = useRouter();
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const tryApply = (e: React.FormEvent) => {
    e.preventDefault();
    const res = applyCoupon(code);
    setMsg({ ok: res.ok, text: res.message });
  };

  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - (subtotal - discount));
  const progress = Math.min(100, ((subtotal - discount) / FREE_SHIPPING_THRESHOLD) * 100);

  if (cart.length === 0) {
    return (
      <div className="container-page py-24 text-center">
        <ShoppingBag size={48} className="mx-auto text-ivory-400 mb-5" strokeWidth={1} />
        <h1 className="font-serif text-3xl text-espresso-900 mb-3">Your bag is empty</h1>
        <p className="text-sm text-espresso-700/70 mb-8 max-w-sm mx-auto">
          Looks like you have not added anything yet. Let's find something you will love.
        </p>
        <Link to="/shop" className="btn-primary inline-flex">Continue Shopping</Link>
      </div>
    );
  }

  return (
    <div className="container-page py-10 lg:py-14">
      <h1 className="font-serif text-4xl md:text-5xl text-espresso-900 mb-8">Shopping Bag</h1>

      {/* Free shipping bar */}
      <div className="bg-ivory-100 p-4 mb-8 rounded-sm">
        <p className="text-sm text-espresso-700 mb-2">
          {remaining > 0 ? (
            <>You are <span className="font-medium text-espresso-900">{formatPKR(remaining)}</span> away from free shipping.</>
          ) : (
            <span className="text-espresso-900 font-medium flex items-center gap-1.5"><Check /> You have unlocked free shipping.</span>
          )}
        </p>
        <div className="h-1.5 bg-ivory-300 rounded-full overflow-hidden">
          <div className="h-full bg-gold-500 transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-10">
        {/* Items */}
        <div className="lg:col-span-2">
          <div className="flex flex-col divide-y divide-ivory-200 border-y border-ivory-200">
            {cart.map((item) => (
              <div key={item.productId + '|' + (item.shade ?? '')} className="py-5 flex gap-4">
                <Link to={`/product/${item.slug}`} className="shrink-0">
                  <div className="w-24 sm:w-28 aspect-[3/4] rounded-sm overflow-hidden bg-ivory-100">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                </Link>
                <div className="flex-1 flex flex-col">
                  <div className="flex justify-between gap-4">
                    <div>
                      <Link to={`/product/${item.slug}`} className="font-serif text-lg text-espresso-900 hover:text-gold-600">{item.name}</Link>
                      {item.shade && <p className="text-xs text-espresso-700/60 mt-0.5">Shade: {item.shade}</p>}
                    </div>
                    <button onClick={() => removeFromCart(item.productId, item.shade)} aria-label="Remove" className="text-espresso-700/50 hover:text-blush-600">
                      <X size={18} />
                    </button>
                  </div>
                  <div className="flex items-end justify-between mt-auto pt-4">
                    <div className="flex items-center border border-ivory-300">
                      <button onClick={() => updateQuantity(item.productId, item.shade, item.quantity - 1)} className="p-2 hover:bg-ivory-100" aria-label="Decrease"><Minus size={14} /></button>
                      <span className="w-10 text-center text-sm font-medium">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.productId, item.shade, item.quantity + 1)} className="p-2 hover:bg-ivory-100" aria-label="Increase"><Plus size={14} /></button>
                    </div>
                    <span className="font-medium text-espresso-900">{formatPKR(item.price * item.quantity)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between mt-6">
            <button onClick={clearCart} className="text-xs tracking-[0.15em] uppercase text-espresso-700/60 hover:text-blush-600">Clear bag</button>
            <Link to="/shop" className="text-xs tracking-[0.15em] uppercase text-espresso-900 link-underline flex items-center gap-1.5">
              <ArrowLeft size={13} /> Continue Shopping
            </Link>
          </div>
        </div>

        {/* Summary */}
        <div className="lg:col-span-1">
          <div className="bg-ivory-100 p-6 rounded-sm sticky top-32">
            <h2 className="font-serif text-2xl text-espresso-900 mb-5">Order Summary</h2>

            {/* Coupon */}
            <div className="mb-5">
              {coupon ? (
                <div className="flex items-center justify-between bg-ivory-50 p-3 border border-gold-500">
                  <div className="flex items-center gap-2">
                    <Tag size={15} className="text-gold-600" />
                    <div>
                      <p className="text-xs font-medium text-espresso-900">{coupon.code}</p>
                      <p className="text-[0.65rem] text-espresso-700/60">{coupon.label}</p>
                    </div>
                  </div>
                  <button onClick={() => { removeCoupon(); setMsg(null); }} aria-label="Remove coupon"><X size={15} /></button>
                </div>
              ) : (
                <form onSubmit={tryApply} className="flex gap-2">
                  <input
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Discount code"
                    className="flex-1 field-input py-2.5 text-sm"
                  />
                  <button type="submit" className="bg-espresso-900 text-ivory-50 px-4 text-xs tracking-[0.15em] uppercase hover:bg-espresso-800">Apply</button>
                </form>
              )}
              {msg && !coupon && <p className="text-xs text-blush-600 mt-2">{msg.text}</p>}
              {!coupon && (
                <p className="text-[0.65rem] text-espresso-700/50 mt-2">
                  Try: {COUPONS.map((c) => c.code).join(', ')}
                </p>
              )}
            </div>

            <div className="space-y-2.5 text-sm border-t border-ivory-300 pt-5">
              <div className="flex justify-between"><span className="text-espresso-700/70">Subtotal</span><span className="text-espresso-900">{formatPKR(subtotal)}</span></div>
              {discount > 0 && <div className="flex justify-between text-blush-600"><span>Discount</span><span>-{formatPKR(discount)}</span></div>}
              <div className="flex justify-between"><span className="text-espresso-700/70">Shipping</span><span className="text-espresso-900">{shipping === 0 ? 'Free' : formatPKR(shipping)}</span></div>
              <div className="flex justify-between text-lg font-serif text-espresso-900 border-t border-ivory-300 pt-3 mt-1">
                <span>Total</span><span>{formatPKR(total)}</span>
              </div>
            </div>
            <p className="text-[0.65rem] text-espresso-700/50 mt-2">Shipping calculated at checkout. Standard rate {formatPKR(SHIPPING_FEE)}.</p>

            <button onClick={() => navigate('/checkout')} className="btn-primary w-full mt-5">
              Proceed to Checkout <ArrowRight size={15} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Check() {
  return <span className="inline-block w-2 h-2 rounded-full bg-gold-500" />;
}
