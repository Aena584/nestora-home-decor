import { ArrowRight, ArrowLeft } from 'lucide-react';
import { useRef } from 'react';
import { Link, useRouter } from '@/router';
import { Reveal } from '@/components/ui';
import { ProductCard } from '@/components/ProductCard';
import {
  CATEGORIES, COLLECTIONS, JOURNAL, BESTSELLERS, NEW_ARRIVALS,
} from '@/data/catalog';

export function HomePage() {
  const { navigate } = useRouter();
  const carouselRef = useRef<HTMLDivElement>(null);

  const scrollCarousel = (dir: 1 | -1) => {
    carouselRef.current?.scrollBy({ left: dir * 320, behavior: 'smooth' });
  };

  return (
    <>
      {/* HERO */}
      <section className="relative h-[88vh] min-h-[600px] max-h-[920px] overflow-hidden bg-espresso-950">
        <img
          src="https://images.pexels.com/photos/7855638/pexels-photo-7855638.jpeg?auto=compress&cs=tinysrgb&h=1200&w=1920"
          alt="NOVIQ beauty editorial campaign"
          className="absolute inset-0 w-full h-full object-cover object-center opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-espresso-950/80 via-espresso-950/30 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-espresso-950/60 to-transparent" />
        <div className="relative container-page h-full flex flex-col justify-center">
          <div className="max-w-xl animate-fade-up">
            <p className="eyebrow text-gold-400 mb-4">The Editorial Campaign</p>
            <h1 className="font-serif text-ivory-50 text-5xl md:text-6xl lg:text-7xl leading-[1.05] mb-5 text-balance">
              Beauty That Feels Like You.
            </h1>
            <p className="text-ivory-200/85 text-lg md:text-xl font-light leading-relaxed max-w-md mb-8">
              Discover your signature glow with thoughtfully curated makeup and skincare essentials.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link to="/shop" className="inline-flex items-center gap-2 bg-ivory-50 text-espresso-900 px-8 py-3.5 text-xs tracking-[0.2em] uppercase font-medium hover:bg-gold-500 transition-colors">
                Explore the Collection <ArrowRight size={15} />
              </Link>
              <Link to="/shop?sort=bestsellers" className="inline-flex items-center gap-2 border border-ivory-50 text-ivory-50 px-8 py-3.5 text-xs tracking-[0.2em] uppercase font-medium hover:bg-ivory-50 hover:text-espresso-900 transition-colors">
                Shop Bestsellers
              </Link>
            </div>
          </div>
        </div>
        <div className="absolute bottom-8 right-8 hidden md:block text-ivory-200/60 text-xs tracking-[0.25em] uppercase">
          Autumn / Winter 2026
        </div>
      </section>

      {/* SHOP BY CATEGORY */}
      <section className="container-page py-20">
        <Reveal>
          <div className="text-center mb-12">
            <p className="eyebrow mb-3">Explore</p>
            <h2 className="font-serif text-4xl md:text-5xl text-espresso-900">Shop by Category</h2>
          </div>
        </Reveal>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 lg:gap-5">
          {CATEGORIES.map((c, i) => (
            <Reveal key={c.slug} delay={(i % 6) * 70}>
              <Link to={`/shop?category=${c.slug}`} className="group block">
                <div className="relative img-zoom aspect-[3/4] rounded-sm overflow-hidden bg-ivory-100">
                  <img src={c.image} alt={c.name} className="w-full h-full object-cover" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-espresso-950/70 via-espresso-950/10 to-transparent" />
                  <div className="absolute bottom-0 inset-x-0 p-4 text-center">
                    <h3 className="font-serif text-ivory-50 text-lg md:text-xl">{c.name}</h3>
                    <p className="text-[0.6rem] tracking-[0.2em] uppercase text-ivory-200/70 mt-0.5">{c.tagline}</p>
                  </div>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* FEATURED COLLECTIONS */}
      <section className="bg-ivory-100 py-20 bg-grain">
        <div className="container-page">
          <Reveal>
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
              <div>
                <p className="eyebrow mb-3">Curated edits</p>
                <h2 className="font-serif text-4xl md:text-5xl text-espresso-900">Featured Collections</h2>
              </div>
              <Link to="/collections" className="text-xs tracking-[0.2em] uppercase text-espresso-900 link-underline">View all collections</Link>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-5">
            {COLLECTIONS.map((col, i) => (
              <Reveal key={col.id} delay={(i % 4) * 80}>
                <Link to={`/collections/${col.id}`} className="group block relative img-zoom aspect-[4/5] rounded-sm overflow-hidden">
                  <img src={col.image} alt={col.name} className="w-full h-full object-cover" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-espresso-950/80 via-espresso-950/20 to-transparent" />
                  <div className="absolute bottom-0 inset-x-0 p-5">
                    <h3 className="font-serif text-ivory-50 text-xl md:text-2xl mb-1.5">{col.name}</h3>
                    <p className="text-xs text-ivory-200/75 leading-relaxed line-clamp-2 mb-3">{col.description}</p>
                    <span className="inline-flex items-center gap-1.5 text-[0.65rem] tracking-[0.2em] uppercase text-gold-400 group-hover:gap-3 transition-all">
                      Discover <ArrowRight size={13} />
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* BESTSELLERS */}
      <section className="container-page py-20">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
            <div>
              <p className="eyebrow mb-3">Loved by many</p>
              <h2 className="font-serif text-4xl md:text-5xl text-espresso-900">Bestsellers</h2>
            </div>
            <Link to="/shop?sort=bestsellers" className="text-xs tracking-[0.2em] uppercase text-espresso-900 link-underline">Shop all bestsellers</Link>
          </div>
        </Reveal>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-10">
          {BESTSELLERS.slice(0, 8).map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
      </section>

      {/* NEW ARRIVALS — carousel */}
      <section className="bg-ivory-100 py-20">
        <div className="container-page">
          <Reveal>
            <div className="flex items-end justify-between gap-4 mb-12">
              <div>
                <p className="eyebrow mb-3">Just landed</p>
                <h2 className="font-serif text-4xl md:text-5xl text-espresso-900">New Arrivals</h2>
              </div>
              <div className="flex gap-2">
                <button onClick={() => scrollCarousel(-1)} aria-label="Previous" className="w-10 h-10 border border-espresso-900 flex items-center justify-center hover:bg-espresso-900 hover:text-ivory-50 transition-colors">
                  <ArrowLeft size={16} />
                </button>
                <button onClick={() => scrollCarousel(1)} aria-label="Next" className="w-10 h-10 border border-espresso-900 flex items-center justify-center hover:bg-espresso-900 hover:text-ivory-50 transition-colors">
                  <ArrowRight size={16} />
                </button>
              </div>
            </div>
          </Reveal>
          <div
            ref={carouselRef}
            className="flex gap-5 overflow-x-auto scrollbar-hide snap-x snap-mandatory pb-2 -mx-5 px-5"
          >
            {NEW_ARRIVALS.concat(NEW_ARRIVALS).map((p, i) => (
              <div key={i} className="snap-start shrink-0 w-[260px] sm:w-[300px]">
                <ProductCard product={p} index={i} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* EDITORIAL — The NOVIQ Beauty Experience */}
      <section className="relative py-24 lg:py-32 bg-espresso-950 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <img src="https://images.pexels.com/photos/39264994/pexels-photo-39264994.jpeg?auto=compress&cs=tinysrgb&h=900&w=1600" alt="" aria-hidden className="w-full h-full object-cover object-center" />
        </div>
        <div className="relative container-page grid lg:grid-cols-2 gap-12 items-center">
          <Reveal>
            <p className="eyebrow text-gold-400 mb-4">The NOVIQ Beauty Experience</p>
            <h2 className="font-serif text-ivory-50 text-4xl md:text-5xl lg:text-6xl leading-[1.08] mb-6 text-balance">
              Beauty is a quiet ritual — and a daily act of self.
            </h2>
            <p className="text-ivory-200/80 text-lg leading-relaxed mb-5 max-w-lg">
              We believe makeup and skincare are not about becoming someone else. They are small, deliberate gestures that help you arrive at yourself — a few minutes each morning that belong to you alone.
            </p>
            <p className="text-ivory-200/70 leading-relaxed mb-8 max-w-lg">
              Every product we curate is chosen for how it performs, how it feels, and how it fits into the life you already have. No excess. No noise. Only the essentials, refined.
            </p>
            <Link to="/about" className="inline-flex items-center gap-2 text-gold-400 text-xs tracking-[0.2em] uppercase border-b border-gold-400 pb-1 hover:gap-3 transition-all">
              Read our philosophy <ArrowRight size={14} />
            </Link>
          </Reveal>
          <Reveal delay={150}>
            <div className="grid grid-cols-2 gap-4">
              <div className="img-zoom aspect-[3/4] rounded-sm overflow-hidden">
                <img src="https://images.pexels.com/photos/5468632/pexels-photo-5468632.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Skincare ritual" className="w-full h-full object-cover" loading="lazy" />
              </div>
              <div className="img-zoom aspect-[3/4] rounded-sm overflow-hidden mt-10">
                <img src="https://images.pexels.com/photos/19163508/pexels-photo-19163508.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Editorial beauty" className="w-full h-full object-cover" loading="lazy" />
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* BEAUTY JOURNAL */}
      <section className="container-page py-20">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
            <div>
              <p className="eyebrow mb-3">From the journal</p>
              <h2 className="font-serif text-4xl md:text-5xl text-espresso-900">The Beauty Journal</h2>
            </div>
          </div>
        </Reveal>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {JOURNAL.map((post, i) => (
            <Reveal key={post.id} delay={(i % 4) * 80}>
              <article className="group cursor-pointer" onClick={() => navigate(`/journal/${post.slug}`)}>
                <div className="img-zoom aspect-[4/5] rounded-sm overflow-hidden bg-ivory-100 mb-4">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover" loading="lazy" />
                </div>
                <p className="text-[0.65rem] tracking-[0.2em] uppercase text-gold-600 mb-2">{post.category} · {post.readTime}</p>
                <h3 className="font-serif text-xl text-espresso-900 group-hover:text-gold-600 transition-colors mb-2">{post.title}</h3>
                <p className="text-sm text-espresso-700/70 leading-relaxed">{post.excerpt}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
