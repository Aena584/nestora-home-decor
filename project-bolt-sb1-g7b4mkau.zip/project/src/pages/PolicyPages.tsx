import { Reveal } from '@/components/ui';
import { Link } from '@/router';
import { Truck, Package, Clock, MapPin, ArrowRight } from 'lucide-react';

export function ShippingPage() {
  return (
    <div className="container-page py-10 lg:py-14 max-w-3xl">
      <Reveal>
        <div className="mb-10">
          <p className="eyebrow mb-3">Customer Care</p>
          <h1 className="font-serif text-4xl md:text-5xl text-espresso-900">Shipping & Delivery</h1>
        </div>
      </Reveal>

      <div className="grid sm:grid-cols-2 gap-5 mb-10">
        {[
          { icon: Truck, t: 'Free over Rs. 7,500', d: 'Complimentary shipping on orders above Rs. 7,500 across Pakistan.' },
          { icon: Clock, t: '2–4 business days', d: 'Typical delivery time for major cities. Remote areas may take up to 6 days.' },
          { icon: MapPin, t: 'Nationwide coverage', d: 'We deliver across Pakistan. Contact us if your area is uncertain.' },
          { icon: Package, t: 'Tracked shipments', d: 'A tracking link is emailed to you as soon as your order is dispatched.' },
        ].map((c, i) => (
          <Reveal key={c.t} delay={i * 80}>
            <div className="bg-ivory-100 p-6 rounded-sm">
              <c.icon size={22} className="text-gold-600 mb-3" />
              <h3 className="font-serif text-lg text-espresso-900 mb-1">{c.t}</h3>
              <p className="text-sm text-espresso-700/75 leading-relaxed">{c.d}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal>
        <div className="space-y-6 text-espresso-700/85 leading-relaxed">
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">Shipping Rates</h2>
            <p>A flat shipping fee of <strong className="text-espresso-900">Rs. 250</strong> applies to orders below Rs. 7,500. Orders of Rs. 7,500 and above ship free of charge.</p>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">Processing Time</h2>
            <p>Orders are processed within 1 business day of being placed. You will receive an order confirmation email immediately, followed by a dispatch email with tracking once your order is on its way.</p>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">Delivery Time</h2>
            <ul className="list-disc pl-5 space-y-1.5">
              <li>Major cities (Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad): 2–4 business days</li>
              <li>Other cities: 3–5 business days</li>
              <li>Remote areas: up to 6 business days</li>
            </ul>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">Cash on Delivery</h2>
            <p>Cash on Delivery is available across most of Pakistan. Please have the exact amount ready at the time of delivery. In some remote locations, advance payment may be required.</p>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">Order Tracking</h2>
            <p>Once dispatched, you will receive an email with a tracking link. If you do not receive tracking within 3 business days, please contact us at care@noviq.cosmetics with your order number.</p>
          </section>
        </div>
      </Reveal>

      <div className="mt-12 text-center">
        <Link to="/contact" className="inline-flex items-center gap-2 text-gold-600 text-xs tracking-[0.2em] uppercase border-b border-gold-500 pb-1 hover:gap-3 transition-all">
          Questions about your delivery? <ArrowRight size={13} />
        </Link>
      </div>
    </div>
  );
}

export function ReturnsPage() {
  return (
    <div className="container-page py-10 lg:py-14 max-w-3xl">
      <Reveal>
        <div className="mb-10">
          <p className="eyebrow mb-3">Customer Care</p>
          <h1 className="font-serif text-4xl md:text-5xl text-espresso-900">Returns & Refunds</h1>
        </div>
      </Reveal>

      <Reveal>
        <div className="space-y-6 text-espresso-700/85 leading-relaxed">
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">7-Day Return Window</h2>
            <p>You may return unopened and unused products in their original packaging within 7 days of delivery. Refunds are issued to the original payment method once the returned items are received and inspected.</p>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">What Can Be Returned</h2>
            <ul className="list-disc pl-5 space-y-1.5">
              <li>Products that are unopened, unused, and in their original packaging</li>
              <li>Items that arrived damaged or defective — please include a photo</li>
              <li>Incorrect items received</li>
            </ul>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">What Cannot Be Returned</h2>
            <ul className="list-disc pl-5 space-y-1.5">
              <li>Used makeup and skincare products, for hygiene reasons</li>
              <li>Products without original packaging</li>
              <li>Items returned outside the 7-day window</li>
            </ul>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">How to Start a Return</h2>
            <ol className="list-decimal pl-5 space-y-1.5">
              <li>Email care@noviq.cosmetics with your order number and the reason for return.</li>
              <li>Our team will respond within 2 business days with return instructions.</li>
              <li>Pack the items securely in their original packaging.</li>
              <li>Ship the package to the address provided. Return shipping costs are the customer's responsibility unless the item was damaged or incorrect.</li>
            </ol>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">Refund Timeline</h2>
            <p>Refunds are processed within 5 business days of receiving and inspecting the returned items. The time for the refund to appear in your account depends on your payment provider.</p>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-3">Exchanges</h2>
            <p>If you would like to exchange a product for a different shade, please return the original item following the steps above and place a new order for the shade you would like.</p>
          </section>
        </div>
      </Reveal>

      <div className="mt-12 text-center">
        <Link to="/contact" className="inline-flex items-center gap-2 text-gold-600 text-xs tracking-[0.2em] uppercase border-b border-gold-500 pb-1 hover:gap-3 transition-all">
          Need help with a return? <ArrowRight size={13} />
        </Link>
      </div>
    </div>
  );
}
