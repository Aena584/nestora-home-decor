import { useState } from 'react';
import { Check, CreditCard, Banknote, ArrowLeft, ShoppingBag } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { useStore, formatPKR } from '@/store/StoreContext';

interface Form {
  name: string; email: string; phone: string; address: string; city: string; postal: string; notes: string;
}

const empty: Form = { name: '', email: '', phone: '', address: '', city: '', postal: '', notes: '' };

export function CheckoutPage() {
  const { cart, subtotal, shipping, discount, total, coupon, clearCart } = useStore();
  const { navigate } = useRouter();
  const [form, setForm] = useState<Form>(empty);
  const [payment, setPayment] = useState<'cod' | 'card'>('cod');
  const [errors, setErrors] = useState<Partial<Record<keyof Form, string>>>({});
  const [placed, setPlaced] = useState(false);
  const [orderId, setOrderId] = useState('');

  const set = (k: keyof Form, v: string) => {
    setForm((f) => ({ ...f, [k]: v }));
    if (errors[k]) setErrors((e) => ({ ...e, [k]: undefined }));
  };

  const validate = () => {
    const e: Partial<Record<keyof Form, string>> = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email';
    if (!/^[0-9+\-\s]{7,15}$/.test(form.phone)) e.phone = 'Enter a valid phone number';
    if (!form.address.trim()) e.address = 'Address is required';
    if (!form.city.trim()) e.city = 'City is required';
    if (!/^\d{4,6}$/.test(form.postal)) e.postal = 'Enter a valid postal code';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const placeOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setOrderId('NVQ-' + Date.now().toString().slice(-8));
    setPlaced(true);
    clearCart();
    window.scrollTo({ top: 0 });
  };

  if (placed) {
    return (
      <div className="container-page py-20 max-w-xl text-center">
        <div className="w-16 h-16 rounded-full bg-gold-500 flex items-center justify-center mx-auto mb-6 animate-scale-in">
          <Check size={30} className="text-espresso-900" />
        </div>
        <p className="eyebrow mb-3">Order confirmed</p>
        <h1 className="font-serif text-4xl text-espresso-900 mb-4">Thank you, {form.name.split(' ')[0]}.</h1>
        <p className="text-espresso-700/80 mb-2">Your order has been received and is being prepared.</p>
        <p className="text-sm text-espresso-700/60 mb-8">
          Order number <span className="font-medium text-espresso-900">{orderId}</span> · A confirmation has been sent to {form.email}.
        </p>
        <div className="bg-ivory-100 p-6 rounded-sm text-left mb-8">
          <h2 className="font-serif text-xl text-espresso-900 mb-3">What happens next</h2>
          <ol className="space-y-2.5 text-sm text-espresso-700/80">
            <li className="flex gap-2"><span className="text-gold-600 font-medium">1.</span> We will pack your order with care.</li>
            <li className="flex gap-2"><span className="text-gold-600 font-medium">2.</span> You will receive a tracking link via email once dispatched.</li>
            <li className="flex gap-2"><span className="text-gold-600 font-medium">3.</span> {payment === 'cod' ? 'Pay in cash when your order arrives.' : 'Your card will be charged on dispatch.'}</li>
          </ol>
          <p className="text-xs text-espresso-700/50 mt-4 pt-4 border-t border-ivory-300">
            This is a demo checkout. No real payment has been processed and no order has been shipped.
          </p>
        </div>
        <Link to="/shop" className="btn-primary inline-flex">Continue Shopping</Link>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="container-page py-24 text-center">
        <ShoppingBag size={48} className="mx-auto text-ivory-400 mb-5" strokeWidth={1} />
        <h1 className="font-serif text-3xl text-espresso-900 mb-3">Your bag is empty</h1>
        <p className="text-sm text-espresso-700/70 mb-8">Add something to your bag before checking out.</p>
        <Link to="/shop" className="btn-primary inline-flex">Browse Products</Link>
      </div>
    );
  }

  return (
    <div className="container-page py-10 lg:py-14">
      <Link to="/cart" className="inline-flex items-center gap-1.5 text-xs tracking-[0.15em] uppercase text-espresso-700 hover:text-espresso-900 mb-6">
        <ArrowLeft size={14} /> Back to bag
      </Link>
      <h1 className="font-serif text-4xl md:text-5xl text-espresso-900 mb-8">Checkout</h1>

      <form onSubmit={placeOrder} className="grid lg:grid-cols-3 gap-10">
        {/* Form */}
        <div className="lg:col-span-2 space-y-8">
          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-4">Contact & Shipping</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="field-label" htmlFor="name">Full Name</label>
                <input id="name" className="field-input" value={form.name} onChange={(e) => set('name', e.target.value)} />
                {errors.name && <p className="text-xs text-blush-600 mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="field-label" htmlFor="email">Email</label>
                <input id="email" type="email" className="field-input" value={form.email} onChange={(e) => set('email', e.target.value)} />
                {errors.email && <p className="text-xs text-blush-600 mt-1">{errors.email}</p>}
              </div>
              <div>
                <label className="field-label" htmlFor="phone">Phone</label>
                <input id="phone" className="field-input" value={form.phone} onChange={(e) => set('phone', e.target.value)} placeholder="+92 3xx xxxxxxx" />
                {errors.phone && <p className="text-xs text-blush-600 mt-1">{errors.phone}</p>}
              </div>
              <div className="sm:col-span-2">
                <label className="field-label" htmlFor="address">Shipping Address</label>
                <input id="address" className="field-input" value={form.address} onChange={(e) => set('address', e.target.value)} />
                {errors.address && <p className="text-xs text-blush-600 mt-1">{errors.address}</p>}
              </div>
              <div>
                <label className="field-label" htmlFor="city">City</label>
                <input id="city" className="field-input" value={form.city} onChange={(e) => set('city', e.target.value)} />
                {errors.city && <p className="text-xs text-blush-600 mt-1">{errors.city}</p>}
              </div>
              <div>
                <label className="field-label" htmlFor="postal">Postal Code</label>
                <input id="postal" className="field-input" value={form.postal} onChange={(e) => set('postal', e.target.value)} />
                {errors.postal && <p className="text-xs text-blush-600 mt-1">{errors.postal}</p>}
              </div>
              <div className="sm:col-span-2">
                <label className="field-label" htmlFor="notes">Order Notes (optional)</label>
                <textarea id="notes" rows={2} className="field-input" value={form.notes} onChange={(e) => set('notes', e.target.value)} />
              </div>
            </div>
          </section>

          <section>
            <h2 className="font-serif text-2xl text-espresso-900 mb-4">Payment Method</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setPayment('cod')}
                className={`flex items-start gap-3 p-4 border text-left transition-colors ${payment === 'cod' ? 'border-espresso-900 bg-ivory-100' : 'border-ivory-300 hover:border-espresso-900'}`}
              >
                <Banknote size={20} className={payment === 'cod' ? 'text-gold-600' : 'text-espresso-700'} />
                <div>
                  <p className="text-sm font-medium text-espresso-900">Cash on Delivery</p>
                  <p className="text-xs text-espresso-700/60 mt-0.5">Pay in cash when your order arrives.</p>
                </div>
              </button>
              <button
                type="button"
                onClick={() => setPayment('card')}
                className={`flex items-start gap-3 p-4 border text-left transition-colors ${payment === 'card' ? 'border-espresso-900 bg-ivory-100' : 'border-ivory-300 hover:border-espresso-900'}`}
              >
                <CreditCard size={20} className={payment === 'card' ? 'text-gold-600' : 'text-espresso-700'} />
                <div>
                  <p className="text-sm font-medium text-espresso-900">Card Payment</p>
                  <p className="text-xs text-espresso-700/60 mt-0.5">Secure card payment (demo only).</p>
                </div>
              </button>
            </div>
            {payment === 'card' && (
              <div className="mt-4 p-4 bg-ivory-100 rounded-sm border border-dashed border-ivory-400">
                <p className="text-xs text-espresso-700/70 mb-3">
                  This is a demo store. No real card details are collected or processed. Do not enter real card information.
                </p>
                <div className="grid grid-cols-3 gap-3 opacity-60">
                  <div className="col-span-3"><input className="field-input py-2.5" placeholder="Card number (demo only)" disabled /></div>
                  <div><input className="field-input py-2.5" placeholder="MM/YY" disabled /></div>
                  <div><input className="field-input py-2.5" placeholder="CVC" disabled /></div>
                </div>
              </div>
            )}
          </section>
        </div>

        {/* Summary */}
        <div className="lg:col-span-1">
          <div className="bg-ivory-100 p-6 rounded-sm sticky top-32">
            <h2 className="font-serif text-2xl text-espresso-900 mb-5">Order Summary</h2>
            <div className="flex flex-col gap-3 mb-4 max-h-64 overflow-y-auto">
              {cart.map((item) => (
                <div key={item.productId + '|' + (item.shade ?? '')} className="flex gap-3 text-sm">
                  <div className="relative shrink-0">
                    <div className="w-14 aspect-[3/4] rounded-sm overflow-hidden bg-ivory-50">
                      <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                    </div>
                    <span className="absolute -top-1.5 -right-1.5 bg-espresso-900 text-ivory-50 text-[0.55rem] w-4 h-4 rounded-full flex items-center justify-center">{item.quantity}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-espresso-900 truncate">{item.name}</p>
                    {item.shade && <p className="text-xs text-espresso-700/60">{item.shade}</p>}
                  </div>
                  <span className="text-espresso-900 font-medium whitespace-nowrap">{formatPKR(item.price * item.quantity)}</span>
                </div>
              ))}
            </div>
            <div className="space-y-2.5 text-sm border-t border-ivory-300 pt-4">
              <div className="flex justify-between"><span className="text-espresso-700/70">Subtotal</span><span>{formatPKR(subtotal)}</span></div>
              {discount > 0 && <div className="flex justify-between text-blush-600"><span>Discount {coupon && `(${coupon.code})`}</span><span>-{formatPKR(discount)}</span></div>}
              <div className="flex justify-between"><span className="text-espresso-700/70">Shipping</span><span>{shipping === 0 ? 'Free' : formatPKR(shipping)}</span></div>
              <div className="flex justify-between text-lg font-serif text-espresso-900 border-t border-ivory-300 pt-3 mt-1">
                <span>Total</span><span>{formatPKR(total)}</span>
              </div>
            </div>
            <button type="submit" className="btn-primary w-full mt-5">Place Order</button>
            <p className="text-[0.65rem] text-espresso-700/50 mt-3 text-center">
              By placing this order you agree to our <Link to="/terms" className="underline">Terms</Link> and <Link to="/privacy" className="underline">Privacy Policy</Link>.
            </p>
          </div>
        </div>
      </form>
    </div>
  );
}
