import { useState } from 'react';
import { User, Package, Heart, LogOut, MapPin } from 'lucide-react';
import { Link } from '@/router';
import { useStore } from '@/store/StoreContext';

export function AccountPage() {
  const { notify } = useStore();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (mode === 'register' && !form.name.trim()) er.name = 'Name is required';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) er.email = 'Enter a valid email';
    if (form.password.length < 6) er.password = 'Password must be at least 6 characters';
    setErrors(er);
    if (Object.keys(er).length) return;
    notify('This is a demo. Account features are not connected to a real backend.');
  };

  return (
    <div className="container-page py-10 lg:py-14 max-w-md">
      <div className="text-center mb-8">
        <p className="eyebrow mb-3">Your space</p>
        <h1 className="font-serif text-4xl text-espresso-900">My Account</h1>
      </div>

      <div className="bg-ivory-100 p-8 rounded-sm">
        <div className="flex border-b border-ivory-300 mb-6">
          <button
            onClick={() => setMode('login')}
            className={`flex-1 pb-3 text-xs tracking-[0.18em] uppercase border-b-2 transition-colors ${mode === 'login' ? 'border-espresso-900 text-espresso-900' : 'border-transparent text-espresso-700/60'}`}
          >
            Sign In
          </button>
          <button
            onClick={() => setMode('register')}
            className={`flex-1 pb-3 text-xs tracking-[0.18em] uppercase border-b-2 transition-colors ${mode === 'register' ? 'border-espresso-900 text-espresso-900' : 'border-transparent text-espresso-700/60'}`}
          >
            Register
          </button>
        </div>

        <form onSubmit={submit} className="space-y-5">
          {mode === 'register' && (
            <div>
              <label className="field-label" htmlFor="a-name">Name</label>
              <input id="a-name" className="field-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              {errors.name && <p className="text-xs text-blush-600 mt-1">{errors.name}</p>}
            </div>
          )}
          <div>
            <label className="field-label" htmlFor="a-email">Email</label>
            <input id="a-email" type="email" className="field-input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            {errors.email && <p className="text-xs text-blush-600 mt-1">{errors.email}</p>}
          </div>
          <div>
            <label className="field-label" htmlFor="a-pass">Password</label>
            <input id="a-pass" type="password" className="field-input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            {errors.password && <p className="text-xs text-blush-600 mt-1">{errors.password}</p>}
          </div>
          <button type="submit" className="btn-primary w-full">
            {mode === 'login' ? 'Sign In' : 'Create Account'}
          </button>
        </form>
        <p className="text-[0.65rem] text-espresso-700/50 mt-4 text-center">
          This is a demo. No real account is created and no data is sent to a server.
        </p>
      </div>

      <div className="grid grid-cols-3 gap-3 mt-6">
        {[
          { icon: Package, label: 'Orders', to: '#' },
          { icon: Heart, label: 'Wishlist', to: '/wishlist' },
          { icon: MapPin, label: 'Addresses', to: '#' },
        ].map((q) => (
          <Link key={q.label} to={q.to} className="flex flex-col items-center gap-2 bg-ivory-100 p-5 rounded-sm hover:bg-ivory-200 transition-colors">
            <q.icon size={20} className="text-espresso-700" />
            <span className="text-xs tracking-[0.15em] uppercase text-espresso-700">{q.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
