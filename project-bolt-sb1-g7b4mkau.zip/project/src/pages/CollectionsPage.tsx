import { Link } from '@/router';
import { Reveal } from '@/components/ui';
import { COLLECTIONS, getByCollection, type CollectionInfo } from '@/data/catalog';
import { ProductCard } from '@/components/ProductCard';
import { ArrowRight } from 'lucide-react';

export function CollectionsPage() {
  return (
    <div className="container-page py-10 lg:py-14">
      <Reveal>
        <div className="text-center mb-14">
          <p className="eyebrow mb-3">Curated edits</p>
          <h1 className="font-serif text-5xl md:text-6xl text-espresso-900 mb-4">Collections</h1>
          <p className="text-espresso-700/70 max-w-lg mx-auto">
            Eight considered edits, each with its own mood — from the lit-from-within glow of the Glow Edit to the deep, smoky drama of the Midnight Edit.
          </p>
        </div>
      </Reveal>

      <div className="flex flex-col gap-20">
        {COLLECTIONS.map((col, i) => (
          <CollectionRow key={col.id} col={col} reverse={i % 2 === 1} />
        ))}
      </div>
    </div>
  );
}

function CollectionRow({ col, reverse }: { col: CollectionInfo; reverse: boolean }) {
  const products = getByCollection(col.id).slice(0, 4);
  return (
    <Reveal>
      <div className={`grid lg:grid-cols-2 gap-10 lg:gap-16 items-center ${reverse ? 'lg:[&>*:first-child]:order-2' : ''}`}>
        <Link to={`/collections/${col.id}`} className="group relative img-zoom aspect-[4/3] rounded-sm overflow-hidden">
          <img src={col.image} alt={col.name} className="w-full h-full object-cover" loading="lazy" />
          <div className="absolute inset-0 bg-gradient-to-t from-espresso-950/60 to-transparent" />
          <div className="absolute bottom-6 left-6">
            <h2 className="font-serif text-ivory-50 text-3xl md:text-4xl mb-2">{col.name}</h2>
            <span className="inline-flex items-center gap-1.5 text-[0.65rem] tracking-[0.2em] uppercase text-gold-400 group-hover:gap-3 transition-all">
              Explore <ArrowRight size={13} />
            </span>
          </div>
        </Link>
        <div>
          <p className="eyebrow mb-3">The Edit</p>
          <h3 className="font-serif text-3xl text-espresso-900 mb-4">{col.name}</h3>
          <p className="text-espresso-700/80 leading-relaxed mb-6 max-w-md">{col.description}</p>
          <Link to={`/collections/${col.id}`} className="btn-secondary">Shop the collection</Link>
        </div>
      </div>
    </Reveal>
  );
}

export function CollectionDetailPage({ id }: { id: string }) {
  const col = COLLECTIONS.find((c) => c.id === id);
  const products = getByCollection(id);

  if (!col) {
    return (
      <div className="container-page py-32 text-center">
        <h1 className="font-serif text-3xl text-espresso-900 mb-4">Collection not found</h1>
        <Link to="/collections" className="btn-secondary">View all collections</Link>
      </div>
    );
  }

  return (
    <div>
      {/* Hero */}
      <div className="relative h-[50vh] min-h-[400px] overflow-hidden bg-espresso-950">
        <img src={col.image} alt={col.name} className="absolute inset-0 w-full h-full object-cover opacity-70" />
        <div className="absolute inset-0 bg-gradient-to-t from-espresso-950/80 to-transparent" />
        <div className="relative container-page h-full flex flex-col justify-end pb-14">
          <p className="eyebrow text-gold-400 mb-3">Collection</p>
          <h1 className="font-serif text-4xl md:text-6xl text-ivory-50 mb-3">{col.name}</h1>
          <p className="text-ivory-200/80 max-w-xl">{col.description}</p>
        </div>
      </div>

      {/* Products */}
      <div className="container-page py-14">
        <p className="text-sm text-espresso-700/70 mb-8">{products.length} product{products.length !== 1 && 's'}</p>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-10">
          {products.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
        </div>
      </div>
    </div>
  );
}
