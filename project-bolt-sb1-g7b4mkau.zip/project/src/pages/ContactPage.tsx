import { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send } from 'lucide-react';
import { useStore } from '@/store/StoreContext';
import { Reveal } from '@/components/ui';

export function ContactPage() {
  const { notify } = useStore();
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const set = (k: string, v: string) => {
    setForm((f) => ({ ...f, [k]: v }));
    if (errors[k]) setErrors((e) => ({ ...e, [k]: '' }));
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (!form.name.trim()) er.name = 'Name is required';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) er.email = 'Enter a valid email';
    if (!form.subject.trim()) er.subject = 'Subject is required';
    if (form.message.trim().length < 10) er.message = 'Message must be at least 10 characters';
    setErrors(er);
    if (Object.keys(er).length) return;
    notify('Your message has been sent. We will reply within 2 business days.');
    setForm({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <div className="container-page py-10 lg:py-14">
      <Reveal>
        <div className="text-center mb-12">
          <p className="eyebrow mb-3">We are here to help</p>
          <h1 className="font-serif text-4xl md:text-5xl text-espresso-900">Contact Us</h1>
          <p className="text-sm text-espresso-700/70 mt-3 max-w-md mx-auto">
            Questions about an order, a product, or anything else? Reach out and our care team will get back to you.
          </p>
        </div>
      </Reveal>

      <div className="grid lg:grid-cols-2 gap-12">
        {/* Info */}
        <div className="space-y-8">
          <Reveal>
            <h2 className="font-serif text-2xl text-espresso-900 mb-5">Get in touch</h2>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start gap-3"><Mail size={18} className="text-gold-600 mt-0.5 shrink-0" /><div><p className="text-[0.65rem] tracking-[0.2em] uppercase text-espresso-700/50">Email</p><p className="text-espresso-900">care@noviq.cosmetics</p></div></li>
              <li className="flex items-start gap-3"><Phone size={18} className="text-gold-600 mt-0.5 shrink-0" /><div><p className="text-[0.65rem] tracking-[0.2em] uppercase text-espresso-700/50">Phone</p><p className="text-espresso-900">+92 300 1234567</p><p className="text-xs text-espresso-700/60">Mon–Sat, 9am–7pm PKT</p></div></li>
              <li className="flex items-start gap-3"><MapPin size={18} className="text-gold-600 mt-0.5 shrink-0" /><div><p className="text-[0.65rem] tracking-[0.2em] uppercase text-espresso-700/50">Address</p><p className="text-espresso-900">NOVIQ Cosmetics</p><p className="text-espresso-700/70">123 Gulberg Main Boulevard<br />Lahore, Pakistan</p></div></li>
              <li className="flex items-start gap-3"><Clock size={18} className="text-gold-600 mt-0.5 shrink-0" /><div><p className="text-[0.65rem] tracking-[0.2em] uppercase text-espresso-700/50">Hours</p><p className="text-espresso-900">Monday – Saturday: 9am – 7pm</p><p className="text-espresso-700/60">Sunday: Closed</p></div></li>
            </ul>
          </Reveal>
          <Reveal delay={100}>
            <div className="bg-ivory-100 p-6 rounded-sm">
              <p className="text-xs text-espresso-700/70 leading-relaxed">
                These are placeholder contact details for this demo store. Replace them with your real business information before going live.
              </p>
            </div>
          </Reveal>
        </div>

        {/* Form */}
        <Reveal delay={150}>
          <form onSubmit={submit} className="space-y-5">
            <div>
              <label className="field-label" htmlFor="c-name">Name</label>
              <input id="c-name" className="field-input" value={form.name} onChange={(e) => set('name', e.target.value)} />
              {errors.name && <p className="text-xs text-blush-600 mt-1">{errors.name}</p>}
            </div>
            <div>
              <label className="field-label" htmlFor="c-email">Email</label>
              <input id="c-email" type="email" className="field-input" value={form.email} onChange={(e) => set('email', e.target.value)} />
              {errors.email && <p className="text-xs text-blush-600 mt-1">{errors.email}</p>}
            </div>
            <div>
              <label className="field-label" htmlFor="c-subject">Subject</label>
              <input id="c-subject" className="field-input" value={form.subject} onChange={(e) => set('subject', e.target.value)} />
              {errors.subject && <p className="text-xs text-blush-600 mt-1">{errors.subject}</p>}
            </div>
            <div>
              <label className="field-label" htmlFor="c-message">Message</label>
              <textarea id="c-message" rows={5} className="field-input" value={form.message} onChange={(e) => set('message', e.target.value)} />
              {errors.message && <p className="text-xs text-blush-600 mt-1">{errors.message}</p>}
            </div>
            <button type="submit" className="btn-primary"><Send size={15} /> Send Message</button>
          </form>
        </Reveal>
      </div>
    </div>
  );
}
