import { useState, useMemo } from 'react';
import { Minus, Plus, ShoppingBag, Heart, ChevronRight, Check, Star, Truck, ShieldCheck, RefreshCw } from 'lucide-react';
import { useRouter, Link } from '@/router';
import { useStore } from '@/store/StoreContext';
import { getProduct, getRelated, PRODUCTS } from '@/data/catalog';
import { Badge, Price, StarRating, Reveal } from '@/components/ui';
import { ProductCard } from '@/components/ProductCard';

export function ProductPage({ slug }: { slug: string }) {
  const { navigate } = useRouter();
  const product = getProduct(slug);
  const { addToCart, toggleWishlist, isWishlisted, cart } = useStore();
  const [activeImg, setActiveImg] = useState(0);
  const [selectedShade, setSelectedShade] = useState<string | undefined>(undefined);
  const [qty, setQty] = useState(1);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<'description' | 'ingredients' | 'usage' | 'specs'>('description');

  const related = useMemo(() => getRelated(slug, 4), [slug]);

  // frequently bought together
  const fbt = useMemo(() => {
    if (!product) return [];
    return PRODUCTS.filter((p) => p.category === product.category && p.slug !== slug).slice(0, 2);
  }, [product, slug]);

  if (!product) {
    return (
      <div className="container-page py-32 text-center">
        <h1 className="font-serif text-3xl text-espresso-900 mb-4">Product not found</h1>
        <Link to="/shop" className="btn-secondary">Back to shop</Link>
      </div>
    );
  }

  const shadeRequired = !!product.shades?.length;
  const wished = isWishlisted(product.id);

  const validateAndAdd = (buyNow = false) => {
    if (shadeRequired && !selectedShade) {
      setError('Please select a shade first.');
      return;
    }
    setError('');
    addToCart(product, selectedShade, qty);
    if (buyNow) navigate('/checkout');
    else navigate('/cart');
  };

  const fbtTotal = fbt.reduce((s, p) => s + p.price, 0) + product.price;

  return (
    <div className="container-page py-8 lg:py-12">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-xs text-espresso-700/60 mb-8 tracking-wide">
        <Link to="/" className="hover:text-espresso-900">Home</Link>
        <ChevronRight size={12} />
        <Link to="/shop" className="hover:text-espresso-900">Shop</Link>
        <ChevronRight size={12} />
        <Link to={`/shop?category=${product.category.toLowerCase().replace(/\s+/g, '-')}`} className="hover:text-espresso-900">{product.category}</Link>
        <ChevronRight size={12} />
        <span className="text-espresso-900">{product.name}</span>
      </nav>

      {/* Main */}
      <div className="grid lg:grid-cols-2 gap-10 lg:gap-16">
        {/* Gallery */}
        <div className="flex flex-col-reverse lg:flex-row gap-4">
          {product.images.length > 1 && (
            <div className="flex lg:flex-col gap-3">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImg(i)}
                  className={`w-16 lg:w-20 aspect-[3/4] rounded-sm overflow-hidden border-2 transition-colors ${activeImg === i ? 'border-espresso-900' : 'border-transparent'}`}
                >
                  <img src={img} alt={`${product.name} view ${i + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
          <div className="flex-1 img-zoom aspect-[3/4] rounded-sm overflow-hidden bg-ivory-100">
            <img src={product.images[activeImg]} alt={product.name} className="w-full h-full object-cover" />
          </div>
        </div>

        {/* Info */}
        <div className="flex flex-col">
          <div className="flex items-center gap-3 mb-3">
            <p className="eyebrow">{product.collection}</p>
            {product.badge && <Badge label={product.badge} />}
          </div>
          <h1 className="font-serif text-3xl md:text-4xl text-espresso-900 mb-4">{product.name}</h1>
          <div className="flex items-center gap-3 mb-5">
            <StarRating rating={product.rating} showValue count={product.reviewCount} />
          </div>
          <Price price={product.price} originalPrice={product.originalPrice} className="text-2xl text-espresso-900 font-medium mb-5" />
          <p className="text-espresso-700/80 leading-relaxed mb-6">{product.shortDesc}</p>

          {/* Shades */}
          {product.shades && (
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2.5">
                <h3 className="field-label mb-0">Shade</h3>
                {selectedShade && <span className="text-xs text-espresso-700/60">{selectedShade}</span>}
              </div>
              <div className="flex flex-wrap gap-2.5">
                {product.shades.map((s) => (
                  <button
                    key={s.name}
                    onClick={() => { setSelectedShade(s.name); setError(''); }}
                    title={s.name}
                    aria-label={s.name}
                    className={`w-9 h-9 rounded-full border-2 transition-all ${selectedShade === s.name ? 'border-espresso-900 scale-110' : 'border-ivory-300 hover:border-espresso-900'}`}
                    style={{ backgroundColor: s.hex }}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Quantity + Add */}
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <div className="flex items-center border border-ivory-300">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Decrease quantity" className="p-3.5 hover:bg-ivory-100"><Minus size={15} /></button>
              <span className="w-12 text-center text-sm font-medium">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} aria-label="Increase quantity" className="p-3.5 hover:bg-ivory-100"><Plus size={15} /></button>
            </div>
            <button onClick={() => validateAndAdd(false)} className="btn-primary flex-1"><ShoppingBag size={15} /> Add to Bag</button>
          </div>
          <button onClick={() => validateAndAdd(true)} className="btn-gold w-full mb-3">Buy Now</button>
          <button
            onClick={() => toggleWishlist(product.id)}
            className="inline-flex items-center justify-center gap-2 text-sm text-espresso-700 hover:text-blush-600 transition-colors mb-2"
          >
            <Heart size={16} className={wished ? 'fill-blush-600 text-blush-600' : ''} />
            {wished ? 'Saved to wishlist' : 'Add to wishlist'}
          </button>

          {error && <p className="text-sm text-blush-600 mt-1 animate-fade-in">{error}</p>}

          {/* Trust badges */}
          <div className="grid grid-cols-3 gap-3 py-5 border-y border-ivory-200 mt-5">
            <div className="flex flex-col items-center text-center gap-1.5">
              <Truck size={20} className="text-gold-600" />
              <span className="text-[0.65rem] text-espresso-700/70">Free shipping over Rs. 7,500</span>
            </div>
            <div className="flex flex-col items-center text-center gap-1.5">
              <RefreshCw size={20} className="text-gold-600" />
              <span className="text-[0.65rem] text-espresso-700/70">7-day easy returns</span>
            </div>
            <div className="flex flex-col items-center text-center gap-1.5">
              <ShieldCheck size={20} className="text-gold-600" />
              <span className="text-[0.65rem] text-espresso-700/70">Authentic products</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-14">
        <div className="flex flex-wrap gap-6 border-b border-ivory-200 mb-6">
          {([
            ['description', 'Description'],
            ['ingredients', 'Ingredients'],
            ['usage', 'How to Use'],
            ['specs', 'Details'],
          ] as const).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`pb-3 text-xs tracking-[0.18em] uppercase border-b-2 transition-colors ${tab === key ? 'border-espresso-900 text-espresso-900' : 'border-transparent text-espresso-700/60 hover:text-espresso-900'}`}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="max-w-2xl text-espresso-700/80 leading-relaxed">
          {tab === 'description' && <p>{product.description}</p>}
          {tab === 'ingredients' && <p className="text-sm">{product.ingredients ?? 'Ingredient information coming soon.'}</p>}
          {tab === 'usage' && <p>{product.usage ?? 'Usage instructions coming soon.'}</p>}
          {tab === 'specs' && (
            <ul className="grid grid-cols-2 gap-3">
              {product.specs.map((s) => (
                <li key={s.label} className="flex flex-col gap-0.5 border-b border-ivory-200 pb-2">
                  <span className="text-[0.65rem] tracking-[0.15em] uppercase text-espresso-700/50">{s.label}</span>
                  <span className="text-sm text-espresso-900">{s.value}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Frequently bought together */}
      {fbt.length > 0 && (
        <div className="mt-16 bg-ivory-100 p-6 lg:p-8 rounded-sm">
          <h2 className="font-serif text-2xl text-espresso-900 mb-5">Frequently Bought Together</h2>
          <div className="flex flex-wrap items-center gap-3 mb-4">
            {[product, ...fbt].map((p, i) => (
              <div key={p.id} className="flex items-center gap-3">
                {i > 0 && <span className="text-espresso-700/40">+</span>}
                <Link to={`/product/${p.slug}`} className="block w-16 sm:w-20 aspect-[3/4] rounded-sm overflow-hidden bg-ivory-50">
                  <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" />
                </Link>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm text-espresso-700">Total for all 3: <span className="font-medium text-espresso-900">Rs. {fbtTotal.toLocaleString('en-PK')}</span></p>
            <button
              onClick={() => {
                addToCart(product, product.shades?.[0]?.name, 1);
                fbt.forEach((p) => addToCart(p, p.shades?.[0]?.name, 1));
                navigate('/cart');
              }}
              className="btn-primary"
            >
              Add all to bag
            </button>
          </div>
        </div>
      )}

      {/* Reviews */}
      <div className="mt-16">
        <h2 className="font-serif text-2xl text-espresso-900 mb-2">Customer Reviews</h2>
        <div className="flex items-center gap-3 mb-6">
          <StarRating rating={product.rating} size={18} />
          <span className="text-sm text-espresso-700/70">{product.rating} out of 5 · {product.reviewCount} reviews</span>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {product.reviews.map((r, i) => (
            <Reveal key={i} delay={i * 80}>
              <div className="border border-ivory-200 p-5 h-full">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-medium text-sm text-espresso-900">{r.author}</span>
                  <span className="text-xs text-espresso-700/50">{r.date}</span>
                </div>
                <div className="flex items-center gap-0.5 mb-2">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <Star key={n} size={13} className={n <= r.rating ? 'fill-gold-500 text-gold-500' : 'fill-ivory-300 text-ivory-300'} />
                  ))}
                </div>
                <h4 className="font-serif text-base text-espresso-900 mb-1.5">{r.title}</h4>
                <p className="text-sm text-espresso-700/80 leading-relaxed">{r.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      {/* Related */}
      {related.length > 0 && (
        <div className="mt-16">
          <h2 className="font-serif text-2xl text-espresso-900 mb-6">You May Also Like</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-10">
            {related.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
          </div>
        </div>
      )}
    </div>
  );
}
