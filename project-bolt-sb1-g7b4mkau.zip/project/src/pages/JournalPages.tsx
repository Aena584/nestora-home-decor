import { Link } from '@/router';
import { Reveal } from '@/components/ui';
import { JOURNAL } from '@/data/catalog';
import { ArrowLeft, ArrowRight, Clock } from 'lucide-react';

export function JournalListPage() {
  return (
    <div className="container-page py-10 lg:py-14">
      <Reveal>
        <div className="text-center mb-14">
          <p className="eyebrow mb-3">Editorial</p>
          <h1 className="font-serif text-4xl md:text-5xl text-espresso-900">The Beauty Journal</h1>
          <p className="text-sm text-espresso-700/70 mt-3 max-w-lg mx-auto">
            Considered writing on makeup, skincare, and the quiet rituals that make beauty feel personal.
          </p>
        </div>
      </Reveal>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {JOURNAL.map((post, i) => (
          <Reveal key={post.id} delay={(i % 3) * 90}>
            <article className="group cursor-pointer" >
              <Link to={`/journal/${post.slug}`}>
                <div className="img-zoom aspect-[4/5] rounded-sm overflow-hidden bg-ivory-100 mb-4">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover" loading="lazy" />
                </div>
                <p className="text-[0.65rem] tracking-[0.2em] uppercase text-gold-600 mb-2">{post.category} · {post.readTime}</p>
                <h2 className="font-serif text-2xl text-espresso-900 group-hover:text-gold-600 transition-colors mb-2">{post.title}</h2>
                <p className="text-sm text-espresso-700/70 leading-relaxed">{post.excerpt}</p>
                <p className="text-xs text-espresso-700/50 mt-3">{post.date}</p>
              </Link>
            </article>
          </Reveal>
        ))}
      </div>
    </div>
  );
}

export function JournalPostPage({ slug }: { slug: string }) {
  const post = JOURNAL.find((p) => p.slug === slug);
  const more = JOURNAL.filter((p) => p.slug !== slug).slice(0, 2);

  if (!post) {
    return (
      <div className="container-page py-32 text-center">
        <h1 className="font-serif text-3xl text-espresso-900 mb-4">Article not found</h1>
        <Link to="/journal" className="btn-secondary">Back to journal</Link>
      </div>
    );
  }

  const body = [
    'Begin with the part of your routine that feels most like you. For most, that is a single, dependable step done consistently — a tinted balm, a lengthening mascara, a serum that makes skin look rested. The point is not to do everything; it is to do one or two things well.',
    'Color, in particular, rewards a light hand. A shade that feels bold on the back of your hand often settles into something soft and flattering once applied. Build gradually, step back, and let the product meet your skin before you decide.',
    'Skincare, meanwhile, is a long game. Hydration and barrier care show their results over weeks, not minutes. Resist the urge to layer too much at once — a simple cleanser, a hydrating serum, and a comfortable moisturizer is a foundation that outperforms most ten-step routines.',
    'Above all, treat beauty as a ritual you look forward to rather than a task to complete. A few unhurried minutes, a product that feels good in the hand, a moment that belongs to you — that is the version worth keeping.',
  ];

  return (
    <div>
      <article className="container-page py-10 lg:py-14 max-w-2xl">
        <Link to="/journal" className="inline-flex items-center gap-1.5 text-xs tracking-[0.15em] uppercase text-espresso-700 hover:text-espresso-900 mb-6">
          <ArrowLeft size={13} /> All articles
        </Link>
        <Reveal>
          <p className="eyebrow mb-3">{post.category}</p>
          <h1 className="font-serif text-4xl md:text-5xl text-espresso-900 mb-4 leading-tight">{post.title}</h1>
          <div className="flex items-center gap-3 text-xs text-espresso-700/60 mb-8">
            <span>{post.date}</span>
            <span className="w-1 h-1 rounded-full bg-espresso-700/40" />
            <span className="flex items-center gap-1"><Clock size={12} /> {post.readTime}</span>
          </div>
          <div className="img-zoom aspect-[16/10] rounded-sm overflow-hidden bg-ivory-100 mb-8">
            <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
          </div>
          <p className="font-serif text-xl text-espresso-800/90 leading-relaxed mb-6 italic">{post.excerpt}</p>
          <div className="space-y-5 text-espresso-700/85 leading-relaxed">
            {body.map((p, i) => <p key={i}>{p}</p>)}
          </div>
        </Reveal>
      </article>

      <div className="container-page py-10 border-t border-ivory-200">
        <h2 className="font-serif text-2xl text-espresso-900 mb-6">Read next</h2>
        <div className="grid sm:grid-cols-2 gap-8">
          {more.map((p) => (
            <Link key={p.id} to={`/journal/${p.slug}`} className="group">
              <div className="img-zoom aspect-[4/3] rounded-sm overflow-hidden bg-ivory-100 mb-3">
                <img src={p.image} alt={p.title} className="w-full h-full object-cover" loading="lazy" />
              </div>
              <h3 className="font-serif text-lg text-espresso-900 group-hover:text-gold-600 transition-colors">{p.title}</h3>
              <span className="inline-flex items-center gap-1 text-xs text-gold-600 mt-1 group-hover:gap-2 transition-all">Read article <ArrowRight size={12} /></span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
