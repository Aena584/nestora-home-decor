export type Category =
  | 'Face Makeup'
  | 'Lip Collection'
  | 'Eye Essentials'
  | 'Skincare'
  | 'Fragrance & Body'
  | 'Beauty Accessories';

export type CategorySlug = 'face-makeup' | 'lip-collection' | 'eye-essentials' | 'skincare' | 'fragrance-body' | 'beauty-accessories';

export interface CategoryInfo {
  name: Category;
  slug: CategorySlug;
  tagline: string;
  image: string;
}

export interface Shade {
  name: string;
  hex: string;
}

export interface Review {
  author: string;
  rating: number;
  date: string;
  title: string;
  body: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  category: Category;
  collection: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  reviews: Review[];
  images: string[];
  shades?: Shade[];
  skinTypes?: string[];
  badge?: 'Bestseller' | 'New Arrival' | 'Limited Edition';
  shortDesc: string;
  description: string;
  ingredients?: string;
  usage?: string;
  specs: { label: string; value: string }[];
  isNew?: boolean;
  bestseller?: boolean;
}

export interface CollectionInfo {
  id: string;
  name: string;
  description: string;
  image: string;
  accent: string;
}

export interface JournalPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  date: string;
  image: string;
}

export interface CartItem {
  productId: string;
  slug: string;
  name: string;
  price: number;
  image: string;
  shade?: string;
  quantity: number;
}

export interface Coupon {
  code: string;
  type: 'percent' | 'fixed';
  value: number;
  label: string;
}

export const COUPONS: Coupon[] = [
  { code: 'WELCOME10', type: 'percent', value: 10, label: '10% off your first order' },
  { code: 'NOVIQ500', type: 'fixed', value: 500, label: 'Rs. 500 off' },
  { code: 'GLOW15', type: 'percent', value: 15, label: '15% off the Glow Edit' },
];

export const SHIPPING_FEE = 250;
export const FREE_SHIPPING_THRESHOLD = 7500;

export const CATEGORIES: CategoryInfo[] = [
  { name: 'Face Makeup', slug: 'face-makeup', tagline: 'A flawless canvas', image: 'https://images.pexels.com/photos/9846610/pexels-photo-9846610.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
  { name: 'Lip Collection', slug: 'lip-collection', tagline: 'Color that speaks', image: 'https://images.pexels.com/photos/7256149/pexels-photo-7256149.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
  { name: 'Eye Essentials', slug: 'eye-essentials', tagline: 'Define your gaze', image: 'https://images.pexels.com/photos/7588594/pexels-photo-7588594.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
  { name: 'Skincare', slug: 'skincare', tagline: 'Rituals for skin', image: 'https://images.pexels.com/photos/16233812/pexels-photo-16233812.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
  { name: 'Fragrance & Body', slug: 'fragrance-body', tagline: 'Linger softly', image: 'https://images.pexels.com/photos/7691162/pexels-photo-7691162.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
  { name: 'Beauty Accessories', slug: 'beauty-accessories', tagline: 'Tools of the craft', image: 'https://images.pexels.com/photos/212236/pexels-photo-212236.jpeg?auto=compress&cs=tinysrgb&h=650&w=940' },
];

export const COLLECTIONS: CollectionInfo[] = [
  { id: 'glow-edit', name: 'THE GLOW EDIT', description: 'Radiant foundations, illuminating primers, highlighters, and glow essentials for a lit-from-within finish.', image: 'https://images.pexels.com/photos/8131568/pexels-photo-8131568.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', accent: 'from-champagne-100 to-champagne-300' },
  { id: 'lip-studio', name: 'THE LIP STUDIO', description: 'Lipsticks, lip glosses, lip liners, and lip oils in shades curated for every mood and moment.', image: 'https://images.pexels.com/photos/4889718/pexels-photo-4889718.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', accent: 'from-blush-100 to-blush-300' },
  { id: 'skin-ritual', name: 'THE SKIN RITUAL', description: 'Cleansers, moisturizers, serums, toners, and face masks for a considered, daily practice.', image: 'https://images.pexels.com/photos/12146904/pexels-photo-12146904.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', accent: 'from-ivory-100 to-ivory-300' },
  { id: 'eye-icons', name: 'THE EYE ICONS', description: 'Mascaras, eyeliners, eyeshadow palettes, and brow products engineered for definition.', image: 'https://images.pexels.com/photos/3286389/pexels-photo-3286389.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', accent: 'from-espresso-700 to-espresso-900' },
  { id: 'nude-affair', name: 'THE NUDE AFFAIR', description: 'Neutral lip colors, everyday makeup, nude palettes, and soft glam essentials.', image: 'https://images.pexels.com/photos/7256120/pexels-photo-7256120.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', accent: 'from-blush-50 to-champagne-200' },
  { id: 'midnight-edit', name: 'THE MIDNIGHT EDIT', description: 'Bold lip colors, smoky eyeshadow palettes, dramatic eyeliners, and evening makeup.', image: 'https://images.pexels.com/photos/4620873/pexels-photo-4620873.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', accent: 'from-espresso-800 to-espresso-950' },
  { id: 'soft-glam', name: 'THE SOFT GLAM COLLECTION', description: 'Blushes, bronzers, soft shimmer products, and natural-looking makeup essentials.', image: 'https://images.pexels.com/photos/7256158/pexels-photo-7256158.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', accent: 'from-blush-200 to-blush-400' },
  { id: 'self-care', name: 'THE SELF-CARE COLLECTION', description: 'Body lotions, body scrubs, lip care, and relaxing skincare essentials for everyday ritual.', image: 'https://images.pexels.com/photos/8076229/pexels-photo-8076229.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', accent: 'from-ivory-200 to-blush-100' },
];

const JOURNAL_IMAGES = [
  'https://images.pexels.com/photos/7855638/pexels-photo-7855638.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/7256154/pexels-photo-7256154.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/5468755/pexels-photo-5468755.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'https://images.pexels.com/photos/39264994/pexels-photo-39264994.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
];

export const JOURNAL: JournalPost[] = [
  { id: 'j1', slug: 'finding-your-perfect-lip-shade', title: 'Finding Your Perfect Lip Shade', excerpt: 'A guide to choosing the right undertone, finish, and depth for lips that feel unmistakably yours.', category: 'Makeup', readTime: '5 min read', date: 'Oct 12, 2026', image: JOURNAL_IMAGES[1] },
  { id: 'j2', slug: 'art-of-everyday-soft-glam', title: 'The Art of Everyday Soft Glam', excerpt: 'A quiet, confident approach to makeup that enhances rather than transforms — built for mornings.', category: 'Editorial', readTime: '7 min read', date: 'Oct 8, 2026', image: JOURNAL_IMAGES[3] },
  { id: 'j3', slug: 'building-a-simple-skincare-routine', title: 'Building a Simple Skincare Routine', excerpt: 'Three steps, done consistently, outperform ten done occasionally. Here is where to begin.', category: 'Skincare', readTime: '6 min read', date: 'Oct 3, 2026', image: JOURNAL_IMAGES[2] },
  { id: 'j4', slug: 'guide-to-a-radiant-makeup-look', title: 'Your Guide to a Radiant Makeup Look', excerpt: 'How to layer primer, foundation, and highlighter for skin that catches light the right way.', category: 'Editorial', readTime: '8 min read', date: 'Sep 28, 2026', image: JOURNAL_IMAGES[0] },
];

const lipImg1 = 'https://images.pexels.com/photos/7256149/pexels-photo-7256149.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const lipImg2 = 'https://images.pexels.com/photos/4889718/pexels-photo-4889718.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const lipImg3 = 'https://images.pexels.com/photos/4416763/pexels-photo-4416763.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const faceImg1 = 'https://images.pexels.com/photos/9846610/pexels-photo-9846610.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const faceImg2 = 'https://images.pexels.com/photos/2732197/pexels-photo-2732197.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const faceImg3 = 'https://images.pexels.com/photos/2688991/pexels-photo-2688991.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const skinImg1 = 'https://images.pexels.com/photos/16233812/pexels-photo-16233812.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const skinImg2 = 'https://images.pexels.com/photos/12146904/pexels-photo-12146904.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const skinImg3 = 'https://images.pexels.com/photos/20171275/pexels-photo-20171275.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const skinImg4 = 'https://images.pexels.com/photos/27357181/pexels-photo-27357181.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const skinImg5 = 'https://images.pexels.com/photos/15930068/pexels-photo-15930068.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const skinImg6 = 'https://images.pexels.com/photos/8101529/pexels-photo-8101529.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const eyeImg1 = 'https://images.pexels.com/photos/7588594/pexels-photo-7588594.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const eyeImg2 = 'https://images.pexels.com/photos/3286389/pexels-photo-3286389.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const eyeImg3 = 'https://images.pexels.com/photos/7290611/pexels-photo-7290611.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const eyeImg4 = 'https://images.pexels.com/photos/4620873/pexels-photo-4620873.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const bodyImg1 = 'https://images.pexels.com/photos/7691162/pexels-photo-7691162.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const bodyImg2 = 'https://images.pexels.com/photos/6690232/pexels-photo-6690232.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const bodyImg3 = 'https://images.pexels.com/photos/7321497/pexels-photo-7321497.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const bodyImg4 = 'https://images.pexels.com/photos/14839826/pexels-photo-14839826.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const accImg1 = 'https://images.pexels.com/photos/212236/pexels-photo-212236.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const accImg2 = 'https://images.pexels.com/photos/7256160/pexels-photo-7256160.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const glowImg = 'https://images.pexels.com/photos/8131568/pexels-photo-8131568.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const lipShades: Shade[] = [
  { name: 'Bare Rose', hex: '#C98B7E' },
  { name: 'Mauve Hour', hex: '#9C6A70' },
  { name: 'Terracotta', hex: '#A85A48' },
  { name: 'Espresso', hex: '#5A3B33' },
];
const foundationShades: Shade[] = [
  { name: 'Porcelain', hex: '#F3E0D0' },
  { name: 'Ivory', hex: '#EAD0B8' },
  { name: 'Sand', hex: '#D8B690' },
  { name: 'Honey', hex: '#C4956A' },
  { name: 'Almond', hex: '#A67550' },
  { name: 'Mocha', hex: '#7D5238' },
];
const nudeShades: Shade[] = [
  { name: 'Nude Beige', hex: '#D9B59E' },
  { name: 'Petal', hex: '#E2C0AE' },
  { name: 'Cashmere', hex: '#C9A48E' },
  { name: 'Taupe', hex: '#A88A78' },
];
const eyeShades: Shade[] = [
  { name: 'Onyx', hex: '#1A1715' },
  { name: 'Espresso', hex: '#3B2A22' },
  { name: 'Bronze', hex: '#8A6240' },
];

function reviews(rating: number, count: number, titles: { title: string; body: string }[]): Review[] {
  return titles.slice(0, Math.min(3, count)).map((t, i) => ({
    author: ['Ayesha M.', 'Sana R.', 'Hira K.', 'Noor A.'][i % 4],
    rating: Math.min(5, Math.max(4, Math.round(rating))),
    date: ['2 weeks ago', '1 month ago', '3 weeks ago'][i % 3],
    title: t.title,
    body: t.body,
  }));
}

export const PRODUCTS: Product[] = [
  {
    id: 'p1', slug: 'velvet-matte-lipstick', name: 'Velvet Matte Lipstick', category: 'Lip Collection', collection: 'The Lip Studio',
    price: 2450, originalPrice: 2900, rating: 4.8, reviewCount: 214,
    reviews: reviews(4.8, 214, [
      { title: 'My new everyday shade', body: 'The formula glides on and stays put through coffee and lunch. Bare Rose is a perfect neutral for my warm undertone.' },
      { title: 'Beautiful, not drying', body: 'Matte but not flat. Wears comfortably for hours without cracking. Worth the price.' },
      { title: 'Lasts all day', body: 'Survived a wedding and still looked fresh by the end. Very impressed with the staying power.' },
    ]),
    images: [lipImg1, lipImg3, lipImg2],
    shades: lipShades,
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'A weightless matte that wears like a stain and feels like a balm.',
    description: 'A whisper-soft matte lipstick with a velvet finish that glides on and settles into a comfortable, second-skin feel. Enriched with squalane and shea complex for a supple, never-dry finish that lasts up to eight hours.',
    ingredients: 'Caprylic/Capric Triglyceride, Squalane, Butyrospermum Parkii (Shea) Butter, Jojoba Esters, Tocopherol, Mica, Naturally Derived Pigments.',
    usage: 'Apply from the center of the lips outward. Blot once for a soft matte finish, or layer for full opacity.',
    specs: [
      { label: 'Finish', value: 'Velvet matte' },
      { label: 'Wear Time', value: 'Up to 8 hours' },
      { label: 'Net Weight', value: '3.5 g' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p2', slug: 'glass-shine-lip-gloss', name: 'Glass Shine Lip Gloss', category: 'Lip Collection', collection: 'The Lip Studio',
    price: 1950, rating: 4.6, reviewCount: 158,
    reviews: reviews(4.6, 158, [
      { title: 'Glossy without being sticky', body: 'The shine is unreal and it does not catch my hair. Wears comfortably all day.' },
      { title: 'Lovely glassy finish', body: 'Adds dimension over liner or alone. A staple in my bag now.' },
    ]),
    images: [lipImg2, lipImg1],
    shades: lipShades,
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'High-shine, non-sticky gloss for a plumped, dimensional finish.',
    description: 'A cushiony, high-shine lip gloss that delivers mirror-like reflectivity without tackiness. Infused with plant-derived glycerin for comfortable, hydrated wear.',
    ingredients: 'Polyglyceryl-3 Diisostearate, Ricinus Communis (Castor) Seed Oil, Helianthus Annuus (Sunflower) Seed Oil, Glycerin, Tocopherol.',
    usage: 'Wear alone or layered over lipstick. Apply to the center of the lips and blend outward.',
    specs: [
      { label: 'Finish', value: 'High shine' },
      { label: 'Texture', value: 'Non-sticky' },
      { label: 'Net Weight', value: '4.5 g' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p3', slug: 'hydrating-lip-oil', name: 'Hydrating Lip Oil', category: 'Lip Collection', collection: 'The Lip Studio',
    price: 1750, rating: 4.7, reviewCount: 96,
    reviews: reviews(4.7, 96, [
      { title: 'Heals my dry lips overnight', body: 'I use this as an overnight treatment and wake up with soft, plump lips. The tint is subtle and pretty.' },
    ]),
    images: [lipImg3, lipImg2],
    shades: nudeShades,
    badge: 'New Arrival', isNew: true,
    shortDesc: 'A nourishing overnight treatment with a soft wash of color.',
    description: 'A treatment-style lip oil that deeply conditions with jojoba and camellia oils while delivering a sheer, buildable tint. Absorbs without residue for lips that feel softer by morning.',
    ingredients: 'Simmondsia Chinensis (Jojoba) Seed Oil, Camellia Oleifera Seed Oil, Caprylic/Capric Triglyceride, Tocopherol, Naturally Derived Pigments.',
    usage: 'Apply a generous layer before bed, or a thin layer through the day for a soft tint.',
    specs: [
      { label: 'Finish', value: 'Sheer, dewy' },
      { label: 'Net Weight', value: '5 g' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p4', slug: 'soft-blur-foundation', name: 'Soft Blur Foundation', category: 'Face Makeup', collection: 'The Glow Edit',
    price: 3850, originalPrice: 4200, rating: 4.7, reviewCount: 187,
    reviews: reviews(4.7, 187, [
      { title: 'Looks like my skin, better', body: 'Medium coverage that evens out redness without masking. The shade match is spot on.' },
      { title: 'Survives humidity', body: 'Wore it through a humid afternoon and it held up without separating. Impressive.' },
    ]),
    images: [faceImg1, faceImg2],
    shades: foundationShades,
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'Medium coverage with a soft-focus, skin-like finish.',
    description: 'A skin-mimicking foundation that blurs imperfections while letting natural texture show through. Buildable from sheer to medium, with glycerin and sodium hyaluronate for all-day comfort.',
    ingredients: 'Aqua, Cyclopentasiloxane, Glycerin, Sodium Hyaluronate, Niacinamide, Tocopherol, Naturally Derived Pigments.',
    usage: 'Shake well. Blend with a damp sponge or brush from the center of the face outward. Build in thin layers.',
    specs: [
      { label: 'Coverage', value: 'Buildable, medium' },
      { label: 'Finish', value: 'Soft, natural' },
      { label: 'Volume', value: '30 ml' },
      { label: 'SPF', value: 'SPF 20' },
    ],
  },
  {
    id: 'p5', slug: 'radiance-primer', name: 'Radiance Primer', category: 'Face Makeup', collection: 'The Glow Edit',
    price: 2950, rating: 4.5, reviewCount: 74,
    reviews: reviews(4.5, 74, [
      { title: 'Subtle glow, real grip', body: 'Foundation stays put longer over this and the glow is not glittery at all. Very natural.' },
    ]),
    images: [glowImg, faceImg1],
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'A luminous grip primer for a lit-from-within base.',
    description: 'A lightweight, luminescent primer that smooths the canvas and adds a soft candlelit glow. Plant-derived glycerin and a subtle optical blur create an even, radiant base for makeup.',
    ingredients: 'Aqua, Glycerin, Dimethicone, Mica, Panthenol, Tocopherol.',
    usage: 'Apply a thin layer to clean, moisturized skin. Wait 30 seconds, then follow with foundation.',
    specs: [
      { label: 'Finish', value: 'Luminous' },
      { label: 'Volume', value: '25 ml' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p6', slug: 'silk-finish-concealer', name: 'Silk Finish Concealer', category: 'Face Makeup', collection: 'The Glow Edit',
    price: 2150, rating: 4.6, reviewCount: 132,
    reviews: reviews(4.6, 132, [
      { title: 'Covers dark circles completely', body: 'One thin layer hides my dark circles without creasing. The applicator is easy to blend.' },
    ]),
    images: [faceImg2, faceImg3],
    shades: foundationShades,
    shortDesc: 'A flexible-coverage concealer with a crease-resistant finish.',
    description: 'A buildable concealer that melts into skin to cover dark circles, blemishes, and redness. Hyaluronic acid and glycerin keep the under-eye area supple all day.',
    ingredients: 'Aqua, Cyclopentasiloxane, Glycerin, Sodium Hyaluronate, Niacinamide, Naturally Derived Pigments.',
    usage: 'Dot under the eyes and on blemishes. Tap with a finger or brush to blend. Set if desired.',
    specs: [
      { label: 'Coverage', value: 'Full, buildable' },
      { label: 'Finish', value: 'Natural satin' },
      { label: 'Volume', value: '7 ml' },
    ],
  },
  {
    id: 'p7', slug: 'liquid-glow-highlighter', name: 'Liquid Glow Highlighter', category: 'Face Makeup', collection: 'The Glow Edit',
    price: 2650, rating: 4.8, reviewCount: 89,
    reviews: reviews(4.8, 89, [
      { title: 'Glass skin in a bottle', body: 'A tiny drop gives an expensive-looking sheen. No chunky glitter, just pure glow.' },
    ]),
    images: [glowImg, faceImg1],
    badge: 'Limited Edition',
    shortDesc: 'A liquid highlighter for a wet, luminous sheen.',
    description: 'An ultra-fine liquid highlighter that delivers a wet-look glow without glitter. Blend with fingertips over or under makeup for a candlelit finish.',
    ingredients: 'Aqua, Glycerin, Mica, Synthetic Fluorphlogopite, Tocopherol.',
    usage: 'Tap onto cheekbones, brow bones, and the bridge of the nose. Layer for intensity.',
    specs: [
      { label: 'Finish', value: 'Wet, luminous' },
      { label: 'Volume', value: '15 ml' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p8', slug: 'cloud-touch-blush', name: 'Cloud Touch Blush', category: 'Face Makeup', collection: 'The Soft Glam Collection',
    price: 2250, rating: 4.7, reviewCount: 64,
    reviews: reviews(4.7, 64, [
      { title: 'Looks like a natural flush', body: 'The powder is so finely milled it blends like a cream. The nude rose shade is a perfect everyday flush.' },
    ]),
    images: [faceImg3, faceImg2],
    shades: nudeShades,
    badge: 'New Arrival', isNew: true,
    shortDesc: 'A finely-milled powder blush for a soft, lived-in flush.',
    description: 'A silky, micronized powder blush that diffuses seamlessly for a natural flush. Buildable color with a soft satin finish that never looks powdery.',
    ingredients: 'Talc, Mica, Zinc Stearate, Caprylic/Capric Triglyceride, Tocopherol, Naturally Derived Pigments.',
    usage: 'Sweep onto the apples of the cheeks and blend upward. Layer for more depth.',
    specs: [
      { label: 'Finish', value: 'Soft satin' },
      { label: 'Net Weight', value: '4 g' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p9', slug: 'sculpt-define-bronzer', name: 'Sculpt & Define Bronzer', category: 'Face Makeup', collection: 'The Soft Glam Collection',
    price: 2350, rating: 4.5, reviewCount: 51,
    reviews: reviews(4.5, 51, [
      { title: 'Natural warmth, no orange', body: 'Finally a bronzer that warms my skin tone without going muddy or orange. Blends beautifully.' },
    ]),
    images: [faceImg2, faceImg3],
    shades: eyeShades,
    shortDesc: 'A matte bronzer for natural dimension and warmth.',
    description: 'A matte, buildable bronzer for soft contouring and a sun-warmed look. The finely-milled powder diffuses without patchiness for a believable, sculpted finish.',
    ingredients: 'Talc, Mica, Zinc Stearate, Caprylic/Capric Triglyceride, Tocopherol, Naturally Derived Pigments.',
    usage: 'Apply to the perimeter of the face and under cheekbones. Blend well for a natural shadow.',
    specs: [
      { label: 'Finish', value: 'Matte' },
      { label: 'Net Weight', value: '8 g' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p10', slug: 'everyday-nude-palette', name: 'Everyday Nude Palette', category: 'Eye Essentials', collection: 'The Nude Affair',
    price: 4250, rating: 4.9, reviewCount: 203,
    reviews: reviews(4.9, 203, [
      { title: 'My most reached-for palette', body: 'Six wearable neutrals that work for day and night. The mattes blend like a dream and the shimmer is tasteful.' },
      { title: 'Worth every rupee', body: 'The shades are so versatile. Pigmentation is excellent without being overwhelming.' },
    ]),
    images: [eyeImg2, eyeImg3],
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'Six curated nude shades for an effortless, everyday eye.',
    description: 'A compact palette of six thoughtfully edited neutrals — three mattes and three soft shimmers — for an everyday eye that transitions from desk to evening. Fine, blendable formula with rich color payoff.',
    ingredients: 'Talc, Mica, Magnesium Stearate, Caprylic/Capric Triglyceride, Tocopherol, Naturally Derived Pigments.',
    usage: 'Use mattes to contour the crease, shimmers on the center of the lid. Build and blend.',
    specs: [
      { label: 'Shades', value: '6' },
      { label: 'Finishes', value: 'Matte, shimmer' },
      { label: 'Net Weight', value: '6 × 1 g' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p11', slug: 'midnight-smoky-palette', name: 'Midnight Smoky Palette', category: 'Eye Essentials', collection: 'The Midnight Edit',
    price: 4650, rating: 4.7, reviewCount: 112,
    reviews: reviews(4.7, 112, [
      { title: 'Smoky eyes made easy', body: 'The transition shades make blending foolproof. The deep espresso is perfect for a soft smoky eye.' },
    ]),
    images: [eyeImg4, eyeImg2],
    badge: 'Limited Edition',
    shortDesc: 'Deep, smoky shades for a dramatic evening eye.',
    description: 'Eight highly pigmented shades curated for smoky, evening looks — from smoldering mattes to molten shimmers. A rich, blendable formula designed to build and diffuse with control.',
    ingredients: 'Talc, Mica, Magnesium Stearate, Caprylic/Capric Triglyceride, Tocopherol, Naturally Derived Pigments.',
    usage: 'Build mattes in the crease, pack shimmers onto the lid, and deepen the outer corner with the darkest shade.',
    specs: [
      { label: 'Shades', value: '8' },
      { label: 'Finishes', value: 'Matte, shimmer, satin' },
      { label: 'Net Weight', value: '8 × 1 g' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p12', slug: 'lengthening-mascara', name: 'Lengthening Mascara', category: 'Eye Essentials', collection: 'The Eye Icons',
    price: 1850, rating: 4.6, reviewCount: 174,
    reviews: reviews(4.6, 174, [
      { title: 'Long, fanned-out lashes', body: 'The brush separates every lash. No clumps, no flaking through the day. My lashes look twice as long.' },
    ]),
    images: [eyeImg1, eyeImg3],
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'A flake-free mascara for fanned, lengthened lashes.',
    description: 'A lengthening and defining mascara with a precision brush that separates and fans each lash. Smudge-resistant formula wears comfortably all day and removes cleanly with warm water.',
    ingredients: 'Aqua, Stearic Acid, Glyceryl Stearate, Copernicia Cerifera (Carnauba) Wax, Tocopherol.',
    usage: 'Wiggle from the base of the lashes to the tips. Build one to two coats.',
    specs: [
      { label: 'Effect', value: 'Length, definition' },
      { label: 'Formula', value: 'Smudge-resistant' },
      { label: 'Volume', value: '8 ml' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p13', slug: 'precision-liquid-eyeliner', name: 'Precision Liquid Eyeliner', category: 'Eye Essentials', collection: 'The Eye Icons',
    price: 1650, rating: 4.5, reviewCount: 98,
    reviews: reviews(4.5, 98, [
      { title: 'Sharpest wing I have done', body: 'The felt tip gives me total control and the black is deeply pigmented. Does not smudge on my oily lids.' },
    ]),
    images: [eyeImg3, eyeImg1],
    shades: eyeShades,
    shortDesc: 'An ultra-precise felt-tip liner for a sharp, smudge-proof wing.',
    description: 'A felt-tip liquid liner with a flexible tip for precise, controlled application. Intensely black, quick-drying, and smudge-proof for a sharp wing that lasts.',
    ingredients: 'Aqua, Acrylates Copolymer, Steareth-20, Phenoxyethanol, Carbon Black.',
    usage: 'Draw from the inner corner outward. For a wing, extend from the outer corner toward the brow tail.',
    specs: [
      { label: 'Tip', value: 'Felt, flexible' },
      { label: 'Formula', value: 'Smudge-proof' },
      { label: 'Volume', value: '3 ml' },
    ],
  },
  {
    id: 'p14', slug: 'brow-definition-pencil', name: 'Brow Definition Pencil', category: 'Eye Essentials', collection: 'The Eye Icons',
    price: 1450, rating: 4.4, reviewCount: 67,
    reviews: reviews(4.4, 67, [
      { title: 'Looks like real hair', body: 'The fine tip draws believable strokes. My brows look fuller but still natural.' },
    ]),
    images: [eyeImg2, eyeImg3],
    shades: eyeShades,
    shortDesc: 'A fine-tipped pencil for natural, hair-like definition.',
    description: 'A dual-ended brow pencil with an ultra-fine tip for hair-like strokes and a spoolie for blending. Buildable, natural-looking color for fuller, defined brows.',
    ingredients: 'Hydrogenated Vegetable Oil, Cera Alba, Mica, Tocopherol, Naturally Derived Pigments.',
    usage: 'Draw short strokes in the direction of hair growth. Blend with the spoolie.',
    specs: [
      { label: 'Tip', value: 'Ultra-fine, 0.9 mm' },
      { label: 'Includes', value: 'Spoolie' },
      { label: 'Net Weight', value: '0.2 g' },
    ],
  },
  {
    id: 'p15', slug: 'daily-hydration-cleanser', name: 'Daily Hydration Cleanser', category: 'Skincare', collection: 'The Skin Ritual',
    price: 2150, rating: 4.6, reviewCount: 121,
    reviews: reviews(4.6, 121, [
      { title: 'Gentle but effective', body: 'Removes my makeup and leaves my skin feeling clean, not tight. My barrier feels calmer since I started using it.' },
    ]),
    images: [skinImg2, skinImg4],
    skinTypes: ['Dry', 'Normal', 'Sensitive'],
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'A gentle gel-to-milk cleanser that respects the skin barrier.',
    description: 'A pH-balanced gel cleanser that transforms into a milky emulsion on contact with water. Lifts impurities and light makeup without stripping, leaving skin soft and comfortable.',
    ingredients: 'Aqua, Coco-Glucoside, Glycerin, Sodium Cocoyl Glutamate, Aloe Barbadensis Leaf Juice, Panthenol, Tocopherol.',
    usage: 'Massage onto damp skin in circular motions. Rinse with lukewarm water. Use morning and night.',
    specs: [
      { label: 'Skin Type', value: 'All, especially dry' },
      { label: 'Volume', value: '150 ml' },
      { label: 'Fragrance', value: 'Naturally scented' },
    ],
  },
  {
    id: 'p16', slug: 'dew-drop-serum', name: 'Dew Drop Serum', category: 'Skincare', collection: 'The Skin Ritual',
    price: 3450, rating: 4.8, reviewCount: 156,
    reviews: reviews(4.8, 156, [
      { title: 'My skin looks plumper', body: 'Within two weeks my skin looked more hydrated and dewy. A little goes a long way.' },
      { title: 'Layering essential', body: 'Sits beautifully under sunscreen and makeup. No pilling at all.' },
    ]),
    images: [skinImg1, skinImg6],
    skinTypes: ['Dry', 'Normal', 'Oily', 'Combination'],
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'A hydrating serum with hyaluronic acid for a dewy, plumped finish.',
    description: 'A lightweight hydrating serum with multi-weight hyaluronic acid and glycerin that draws moisture into the skin for a plumped, dewy finish. Layers seamlessly under other products.',
    ingredients: 'Aqua, Glycerin, Sodium Hyaluronate, Panthenol, Niacinamide, Tocopherol.',
    usage: 'Apply 3-4 drops to clean skin before moisturizer. Use morning and night.',
    specs: [
      { label: 'Key Actives', value: 'Hyaluronic acid, niacinamide' },
      { label: 'Volume', value: '30 ml' },
      { label: 'Fragrance-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p17', slug: 'barrier-comfort-moisturizer', name: 'Barrier Comfort Moisturizer', category: 'Skincare', collection: 'The Skin Ritual',
    price: 2850, rating: 4.7, reviewCount: 88,
    reviews: reviews(4.7, 88, [
      { title: 'Soothing and rich', body: 'My skin feels calm and cushioned. Perfect for dry, reactive skin without being heavy.' },
    ]),
    images: [skinImg3, skinImg5],
    skinTypes: ['Dry', 'Sensitive', 'Normal'],
    shortDesc: 'A cushioning moisturizer for a calm, supported skin barrier.',
    description: 'A rich yet breathable moisturizer with ceramides and shea complex to support the moisture barrier. Absorbs without greasiness for soft, comfortable skin.',
    ingredients: 'Aqua, Glycerin, Caprylic/Capric Triglyceride, Ceramide NP, Butyrospermum Parkii (Shea) Butter, Panthenol, Tocopherol.',
    usage: 'Apply to face and neck after serum. Use morning and night.',
    specs: [
      { label: 'Key Actives', value: 'Ceramides, shea' },
      { label: 'Volume', value: '50 ml' },
      { label: 'Fragrance-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p18', slug: 'rosewater-toner', name: 'Rosewater Toner', category: 'Skincare', collection: 'The Skin Ritual',
    price: 1650, rating: 4.5, reviewCount: 54,
    reviews: reviews(4.5, 54, [
      { title: 'Refreshing and calming', body: 'A quick spritz refreshes my skin and sets my makeup. The rose scent is light and natural.' },
    ]),
    images: [skinImg4, skinImg2],
    skinTypes: ['All'],
    shortDesc: 'A refreshing rosewater mist to balance and prep skin.',
    description: 'A fine, refreshing facial mist with distilled rosewater and glycerin to balance, hydrate, and prepare skin for the rest of your routine. Use as a toner or throughout the day.',
    ingredients: 'Rosa Damascena Flower Water, Glycerin, Panthenol, Tocopherol.',
    usage: 'Mist over clean skin before serum, or anytime for a refresh.',
    specs: [
      { label: 'Volume', value: '100 ml' },
      { label: 'Skin Type', value: 'All' },
    ],
  },
  {
    id: 'p19', slug: 'overnight-renewal-mask', name: 'Overnight Renewal Mask', category: 'Skincare', collection: 'The Self-Care Collection',
    price: 3250, rating: 4.6, reviewCount: 73,
    reviews: reviews(4.6, 73, [
      { title: 'Wake up to soft skin', body: 'I apply this twice a week and my skin looks rested and smooth by morning. Not greasy at all.' },
    ]),
    images: [skinImg5, skinImg3],
    skinTypes: ['Normal', 'Dry', 'Combination'],
    badge: 'New Arrival', isNew: true,
    shortDesc: 'A sleeping mask for softer, renewed skin by morning.',
    description: 'An overnight gel-cream mask with a gentle complex of lactic acid and squalane that supports natural renewal while you sleep. Wake to softer, more even-looking skin.',
    ingredients: 'Aqua, Glycerin, Squalane, Lactic Acid, Panthenol, Sodium Hyaluronate, Tocopherol.',
    usage: 'Apply a thin layer as the last step of your evening routine 2-3 times a week. No need to rinse.',
    specs: [
      { label: 'Key Actives', value: 'Lactic acid, squalane' },
      { label: 'Volume', value: '50 ml' },
      { label: 'Use', value: '2-3 times weekly' },
    ],
  },
  {
    id: 'p20', slug: 'gentle-exfoliating-scrub', name: 'Gentle Exfoliating Scrub', category: 'Skincare', collection: 'The Self-Care Collection',
    price: 1850, rating: 4.4, reviewCount: 46,
    reviews: reviews(4.4, 46, [
      { title: 'Smooth, not scratchy', body: 'The grains are fine enough that it does not irritate. Skin feels smooth and polished after.' },
    ]),
    images: [skinImg6, skinImg4],
    skinTypes: ['All'],
    shortDesc: 'A gentle physical scrub for a smooth, polished complexion.',
    description: 'A creamy physical exfoliant with fine jojoba beads and rice powder that buffs away dullness without micro-tears. Skin feels smooth and refined, never tight.',
    ingredients: 'Aqua, Jojoba Esters, Oryza Sativa (Rice) Powder, Glycerin, Caprylic/Capric Triglyceride, Tocopherol.',
    usage: 'Massage onto damp skin in gentle circles once or twice a week. Rinse thoroughly.',
    specs: [
      { label: 'Use', value: '1-2 times weekly' },
      { label: 'Volume', value: '75 ml' },
      { label: 'Skin Type', value: 'All' },
    ],
  },
  {
    id: 'p21', slug: 'velvet-body-lotion', name: 'Velvet Body Lotion', category: 'Fragrance & Body', collection: 'The Self-Care Collection',
    price: 2450, rating: 4.7, reviewCount: 69,
    reviews: reviews(4.7, 69, [
      { title: 'Soft, scented skin', body: 'Absorbs fast and leaves my skin soft with a subtle warm scent. Not sticky at all.' },
    ]),
    images: [bodyImg1, bodyImg2],
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'A richly hydrating body lotion with a warm, soft scent.',
    description: 'A fast-absorbing body lotion with shea and glycerin for lasting hydration, finished with a soft, warm fragrance. Leaves skin velvety, not greasy.',
    ingredients: 'Aqua, Glycerin, Butyrospermum Parkii (Shea) Butter, Caprylic/Capric Triglyceride, Panthenol, Tocopherol, Fragrance.',
    usage: 'Massage into clean skin daily, focusing on dry areas.',
    specs: [
      { label: 'Volume', value: '250 ml' },
      { label: 'Scent', value: 'Warm, soft' },
    ],
  },
  {
    id: 'p22', slug: 'nourishing-lip-balm', name: 'Nourishing Lip Balm', category: 'Lip Collection', collection: 'The Self-Care Collection',
    price: 950, rating: 4.6, reviewCount: 112,
    reviews: reviews(4.6, 112, [
      { title: 'My go-to balm', body: 'Heals chapped lips overnight. No scent, no flavor, just soft lips. Great under lipstick too.' },
    ]),
    images: [lipImg1, lipImg2],
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'A nourishing everyday balm for soft, conditioned lips.',
    description: 'A cushioning lip balm with shea, beeswax, and vitamin E to condition and protect. Non-sticky, fragrance-free, and perfect for everyday wear.',
    ingredients: 'Butyrospermum Parkii (Shea) Butter, Cera Alba, Caprylic/Capric Triglyceride, Tocopherol.',
    usage: 'Apply as needed throughout the day and before bed.',
    specs: [
      { label: 'Net Weight', value: '4 g' },
      { label: 'Fragrance-Free', value: 'Yes' },
    ],
  },
  {
    id: 'p23', slug: 'body-mist', name: 'Body Mist', category: 'Fragrance & Body', collection: 'The Self-Care Collection',
    price: 1650, rating: 4.5, reviewCount: 58,
    reviews: reviews(4.5, 58, [
      { title: 'Light and lingering', body: 'The scent is soft and lasts a few hours without being overpowering. Perfect for daytime.' },
    ]),
    images: [bodyImg4, bodyImg3],
    badge: 'New Arrival', isNew: true,
    shortDesc: 'A light, lingering body mist for an everyday signature.',
    description: 'A soft, wearable body mist with a delicate floral-musk composition. Light enough for daytime, layered for evening. Skin-friendly and non-irritating.',
    ingredients: 'Aqua, Alcohol Denat., Fragrance, Glycerin, Tocopherol.',
    usage: 'Mist onto pulse points and over clothing. Reapply as desired.',
    specs: [
      { label: 'Volume', value: '100 ml' },
      { label: 'Scent', value: 'Floral, soft musk' },
    ],
  },
  {
    id: 'p24', slug: 'beauty-brush-set', name: 'Beauty Brush Set', category: 'Beauty Accessories', collection: 'The Soft Glam Collection',
    price: 3950, rating: 4.8, reviewCount: 81,
    reviews: reviews(4.8, 81, [
      { title: 'Soft and precise', body: 'The bristles are so soft and the handles feel substantial. Every brush I need in one set.' },
    ]),
    images: [accImg2, accImg1],
    badge: 'Bestseller', bestseller: true,
    shortDesc: 'A curated set of essential brushes for face and eyes.',
    description: 'A set of six essential brushes with soft, synthetic bristles and weighted handles — for foundation, powder, blush, blending, shading, and detail work. Vegan and cruelty-free.',
    usage: 'Use each brush for its intended purpose. Clean weekly with a gentle brush cleanser.',
    specs: [
      { label: 'Includes', value: '6 brushes + case' },
      { label: 'Bristles', value: 'Synthetic, vegan' },
      { label: 'Cruelty-Free', value: 'Yes' },
    ],
  },
];

export function getProduct(slug: string): Product | undefined {
  return PRODUCTS.find((p) => p.slug === slug);
}

export function getByCategory(slug: string): Product[] {
  const cat = CATEGORIES.find((c) => c.slug === slug);
  if (!cat) return [];
  return PRODUCTS.filter((p) => p.category === cat.name);
}

export function getByCollection(id: string): Product[] {
  return PRODUCTS.filter((p) => collectionToId(p.collection) === id);
}

export function collectionToId(name: string): string {
  return name.toLowerCase().replace(/^the\s+/, '').replace(/\s+/g, '-').replace('collection', 'collection').trim();
}

export function getRelated(slug: string, count = 4): Product[] {
  const product = getProduct(slug);
  if (!product) return [];
  return PRODUCTS.filter((p) => p.category === product.category && p.slug !== slug).slice(0, count);
}

export const BESTSELLERS = PRODUCTS.filter((p) => p.bestseller);
export const NEW_ARRIVALS = PRODUCTS.filter((p) => p.isNew);

export const ALL_SHADES = Array.from(new Set(PRODUCTS.flatMap((p) => p.shades?.map((s) => s.name) ?? [])));
export const ALL_SKIN_TYPES = ['Dry', 'Normal', 'Oily', 'Combination', 'Sensitive', 'All'];
export const PRICE_MIN = Math.min(...PRODUCTS.map((p) => p.price));
export const PRICE_MAX = Math.max(...PRODUCTS.map((p) => p.price));
