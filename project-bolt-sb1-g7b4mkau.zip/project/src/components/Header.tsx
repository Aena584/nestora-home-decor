import { useEffect, useState, useRef } from 'react';
import { Search, Heart, ShoppingBag, User, Menu, X, ChevronRight } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { useStore } from '@/store/StoreContext';
import { CATEGORIES } from '@/data/catalog';

const NAV = [
  { label: 'Home', to: '/' },
  { label: 'Shop All', to: '/shop' },
  { label: 'Makeup', to: '/shop?category=face-makeup' },
  { label: 'Skincare', to: '/shop?category=skincare' },
  { label: 'Collections', to: '/collections' },
  { label: 'About Us', to: '/about' },
];

const announcements = [
  'Complimentary shipping on orders over Rs. 7,500',
  'New: The Midnight Edit has landed — limited quantities',
  'Use code WELCOME10 for 10% off your first order',
];

export function Header() {
  const { cartCount, wishlist } = useStore();
  const { navigate, route } = useRouter();
  const [scrolled, setScrolled] = useState(false);
  const [megaOpen, setMegaOpen] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchVal, setSearchVal] = useState('');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [annIdx, setAnnIdx] = useState(0);
  const megaTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setAnnIdx((i) => (i + 1) % announcements.length), 4500);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    setDrawerOpen(false);
    setSearchOpen(false);
    setMegaOpen(null);
  }, [route.path]);

  const openMega = (label: string) => {
    if (megaTimer.current) clearTimeout(megaTimer.current);
    setMegaOpen(label);
  };
  const closeMegaSoon = () => {
    if (megaTimer.current) clearTimeout(megaTimer.current);
    megaTimer.current = setTimeout(() => setMegaOpen(null), 120);
  };

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchVal.trim()) {
      navigate(`/shop?q=${encodeURIComponent(searchVal.trim())}`);
      setSearchOpen(false);
      setSearchVal('');
    }
  };

  return (
    <header className="sticky top-0 z-40">
      {/* Announcement bar */}
      <div className="bg-espresso-950 text-ivory-100 text-center py-2 text-[0.68rem] tracking-[0.2em] uppercase overflow-hidden">
        <div key={annIdx} className="animate-fade-in">{announcements[annIdx]}</div>
      </div>

      {/* Main bar */}
      <div
        className={`transition-all duration-300 ${scrolled ? 'bg-ivory-50/95 backdrop-blur shadow-sm' : 'bg-ivory-50'}`}
        onMouseLeave={closeMegaSoon}
      >
        <div className="container-page flex items-center justify-between h-16 lg:h-20">
          {/* Left: mobile + nav */}
          <div className="flex items-center gap-6">
            <button
              className="lg:hidden text-espresso-900"
              onClick={() => setDrawerOpen(true)}
              aria-label="Open menu"
            >
              <Menu size={22} />
            </button>
            <nav className="hidden lg:flex items-center gap-7 text-[0.7rem] tracking-[0.18em] uppercase text-espresso-900 font-medium">
              {NAV.slice(0, 5).map((n) => (
                <div
                  key={n.label}
                  onMouseEnter={() => (n.label === 'Shop All' ? openMega('Shop All') : n.label === 'Makeup' ? openMega('Makeup') : closeMegaSoon())}
                >
                  <Link to={n.to} className="link-underline py-2">{n.label}</Link>
                </div>
              ))}
              <Link to="/about" className="link-underline py-2">About</Link>
            </nav>
          </div>

          {/* Center: Logo */}
          <Link to="/" className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center leading-none">
            <span className="font-serif text-2xl lg:text-[1.7rem] tracking-[0.35em] text-espresso-900 font-semibold pl-[0.35em]">NOVIQ</span>
            <span className="text-[0.5rem] tracking-[0.45em] uppercase text-gold-600 mt-0.5">Cosmetics</span>
          </Link>

          {/* Right: actions */}
          <div className="flex items-center gap-4 lg:gap-5 text-espresso-900">
            <button onClick={() => setSearchOpen((s) => !s)} aria-label="Search" className="hover:text-gold-600 transition-colors">
              <Search size={20} />
            </button>
            <Link to="/account" aria-label="Account" className="hidden sm:block hover:text-gold-600 transition-colors">
              <User size={20} />
            </Link>
            <Link to="/wishlist" aria-label="Wishlist" className="relative hover:text-gold-600 transition-colors">
              <Heart size={20} />
              {wishlist.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-blush-600 text-ivory-50 text-[0.55rem] font-medium w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </Link>
            <Link to="/cart" aria-label="Shopping bag" className="relative hover:text-gold-600 transition-colors">
              <ShoppingBag size={20} />
              {cartCount > 0 && (
                <span key={cartCount} className="absolute -top-1.5 -right-1.5 bg-espresso-900 text-ivory-50 text-[0.55rem] font-medium w-4 h-4 rounded-full flex items-center justify-center animate-count-bump">
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
        </div>

        {/* Search bar */}
        {searchOpen && (
          <div className="border-t border-ivory-200 bg-ivory-50 animate-fade-down">
            <form onSubmit={submitSearch} className="container-page py-4 flex items-center gap-3">
              <Search size={18} className="text-espresso-700/60" />
              <input
                autoFocus
                value={searchVal}
                onChange={(e) => setSearchVal(e.target.value)}
                placeholder="Search products, shades, collections…"
                className="flex-1 bg-transparent outline-none text-sm text-espresso-900 placeholder:text-espresso-700/40"
              />
              <button type="submit" className="text-[0.7rem] tracking-[0.2em] uppercase text-gold-600 font-medium">Search</button>
              <button type="button" onClick={() => setSearchOpen(false)} aria-label="Close search"><X size={18} /></button>
            </form>
          </div>
        )}

        {/* Mega menu */}
        {megaOpen && (
          <div
            className="hidden lg:block absolute left-0 right-0 top-full bg-ivory-50 border-t border-ivory-200 shadow-lg animate-fade-down"
            onMouseEnter={() => openMega(megaOpen)}
            onMouseLeave={closeMegaSoon}
          >
            <div className="container-page py-10 grid grid-cols-3 gap-8">
              {CATEGORIES.map((c) => (
                <Link key={c.slug} to={`/shop?category=${c.slug}`} className="group flex items-center gap-4">
                  <div className="w-20 h-20 img-zoom rounded-sm overflow-hidden">
                    <img src={c.image} alt={c.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="font-serif text-lg text-espresso-900 group-hover:text-gold-600 transition-colors">{c.name}</h4>
                    <p className="text-xs text-espresso-700/60">{c.tagline}</p>
                  </div>
                  <ChevronRight size={16} className="ml-auto text-espresso-700/40 group-hover:translate-x-1 transition-transform" />
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Mobile drawer */}
      {drawerOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-espresso-950/40 backdrop-blur-sm animate-fade-in" onClick={() => setDrawerOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-[82%] max-w-sm bg-ivory-50 p-6 animate-slide-in-right flex flex-col">
            <div className="flex items-center justify-between mb-8">
              <span className="font-serif text-xl tracking-[0.3em] text-espresso-900">NOVIQ</span>
              <button onClick={() => setDrawerOpen(false)} aria-label="Close menu"><X size={22} /></button>
            </div>
            <nav className="flex flex-col divide-y divide-ivory-200">
              {NAV.map((n) => (
                <Link key={n.label} to={n.to} className="py-3.5 text-sm tracking-[0.15em] uppercase text-espresso-900 flex items-center justify-between">
                  {n.label} <ChevronRight size={16} className="text-espresso-700/40" />
                </Link>
              ))}
            </nav>
            <div className="mt-6 pt-6 border-t border-ivory-200">
              <p className="eyebrow mb-3">Categories</p>
              <div className="flex flex-col gap-2.5">
                {CATEGORIES.map((c) => (
                  <Link key={c.slug} to={`/shop?category=${c.slug}`} className="text-sm text-espresso-700 hover:text-gold-600">{c.name}</Link>
                ))}
              </div>
            </div>
            <div className="mt-auto pt-6 flex flex-col gap-2 text-sm text-espresso-700">
              <Link to="/account">Account</Link>
              <Link to="/wishlist">Wishlist</Link>
              <Link to="/contact">Contact</Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
