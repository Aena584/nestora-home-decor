import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Star } from 'lucide-react';

export function Reveal({ children, delay = 0, className = '' }: { children: ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setVisible(true);
            obs.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={`reveal ${visible ? 'is-visible' : ''} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

export function StarRating({ rating, size = 14, showValue = false, count }: { rating: number; size?: number; showValue?: boolean; count?: number }) {
  return (
    <div className="flex items-center gap-1.5">
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((n) => (
          <Star
            key={n}
            size={size}
            className={n <= Math.round(rating) ? 'fill-gold-500 text-gold-500' : 'fill-ivory-300 text-ivory-300'}
          />
        ))}
      </div>
      {showValue && <span className="text-xs text-espresso-700">{rating.toFixed(1)}</span>}
      {typeof count === 'number' && <span className="text-xs text-espresso-700/60">({count})</span>}
    </div>
  );
}

export function Price({ price, originalPrice, className = '' }: { price: number; originalPrice?: number; className?: string }) {
  return (
    <div className="flex items-baseline gap-2">
      <span className={className}>Rs. {price.toLocaleString('en-PK')}</span>
      {originalPrice && originalPrice > price && (
        <span className="text-sm text-espresso-700/40 line-through">Rs. {originalPrice.toLocaleString('en-PK')}</span>
      )}
    </div>
  );
}

const badgeStyles: Record<string, string> = {
  Bestseller: 'bg-espresso-900 text-ivory-50',
  'New Arrival': 'bg-gold-500 text-espresso-900',
  'Limited Edition': 'bg-blush-600 text-ivory-50',
};

export function Badge({ label }: { label: string }) {
  return <span className={`product-badge ${badgeStyles[label] ?? 'bg-ivory-300 text-espresso-900'}`}>{label}</span>;
}

export function Toasts() {
  return null;
}
