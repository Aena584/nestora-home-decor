import { CheckCircle2, X } from 'lucide-react';
import { useStore } from '@/store/StoreContext';

export function Toasts() {
  const { toasts, dismissToast } = useStore();
  return (
    <div className="fixed bottom-6 right-6 z-[60] flex flex-col gap-2.5 max-w-sm">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="flex items-center gap-3 bg-espresso-900 text-ivory-50 px-4 py-3 shadow-lg animate-fade-up"
        >
          <CheckCircle2 size={18} className="text-gold-400 shrink-0" />
          <span className="text-sm flex-1">{t.message}</span>
          <button onClick={() => dismissToast(t.id)} aria-label="Dismiss" className="text-ivory-200/60 hover:text-ivory-50">
            <X size={16} />
          </button>
        </div>
      ))}
    </div>
  );
}
