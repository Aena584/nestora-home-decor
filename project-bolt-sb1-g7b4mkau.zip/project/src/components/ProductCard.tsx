import { Heart, ShoppingBag } from 'lucide-react';
import type { Product } from '@/data/catalog';
import { Link } from '@/router';
import { useStore } from '@/store/StoreContext';
import { Badge, Price, StarRating } from '@/components/ui';

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const { toggleWishlist, isWishlisted, addToCart } = useStore();
  const wished = isWishlisted(product.id);

  const quickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, product.shades?.[0]?.name, 1);
  };

  const wish = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  return (
    <article
      className="group relative flex flex-col animate-fade-up"
      style={{ animationDelay: `${(index % 4) * 60}ms` }}
    >
      <Link to={`/product/${product.slug}`} className="block">
        <div className="relative img-zoom bg-ivory-100 aspect-[3/4] overflow-hidden">
          <img
            src={product.images[0]}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-cover"
          />
          {product.images[1] && (
            <img
              src={product.images[1]}
              alt=""
              aria-hidden="true"
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover opacity-0 transition-opacity duration-700 group-hover:opacity-100"
            />
          )}
          {product.badge && (
            <div className="absolute top-3 left-3">
              <Badge label={product.badge} />
            </div>
          )}
          <button
            onClick={wish}
            aria-label={wished ? 'Remove from wishlist' : 'Add to wishlist'}
            className={`absolute top-3 right-3 w-9 h-9 flex items-center justify-center rounded-full bg-ivory-50/90 backdrop-blur transition-all hover:scale-110 ${wished ? 'text-blush-600' : 'text-espresso-900'}`}
          >
            <Heart size={16} className={wished ? 'fill-blush-600' : ''} />
          </button>
          <button
            onClick={quickAdd}
            className="absolute bottom-0 inset-x-0 bg-espresso-900 text-ivory-50 py-3 text-[0.65rem] tracking-[0.2em] uppercase font-medium flex items-center justify-center gap-2 translate-y-full group-hover:translate-y-0 transition-transform duration-500 hover:bg-espresso-800"
          >
            <ShoppingBag size={14} /> Quick Add
          </button>
        </div>
      </Link>

      <div className="pt-4 flex flex-col gap-1.5">
        <p className="text-[0.65rem] tracking-[0.2em] uppercase text-espresso-700/60">{product.collection}</p>
        <Link to={`/product/${product.slug}`} className="font-serif text-lg text-espresso-900 hover:text-gold-600 transition-colors">
          {product.name}
        </Link>
        <StarRating rating={product.rating} count={product.reviewCount} />
        {product.shades && (
          <div className="flex items-center gap-1.5 pt-1">
            {product.shades.slice(0, 5).map((s) => (
              <span
                key={s.name}
                title={s.name}
                className="w-4 h-4 rounded-full border border-ivory-300"
                style={{ backgroundColor: s.hex }}
              />
            ))}
            {product.shades.length > 5 && <span className="text-xs text-espresso-700/50">+{product.shades.length - 5}</span>}
          </div>
        )}
        <Price price={product.price} originalPrice={product.originalPrice} className="text-espresso-900 font-medium mt-1" />
      </div>
    </article>
  );
}
