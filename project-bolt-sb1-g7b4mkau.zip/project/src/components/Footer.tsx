import { useState } from 'react';
import { Instagram, Facebook, Youtube, Mail, MapPin, Phone } from 'lucide-react';
import { Link, useRouter } from '@/router';
import { useStore } from '@/store/StoreContext';

const FOOTER_LINKS = {
  Shop: [
    { label: 'Shop All', to: '/shop' },
    { label: 'Collections', to: '/collections' },
    { label: 'Bestsellers', to: '/shop?sort=bestsellers' },
    { label: 'New Arrivals', to: '/shop?sort=newest' },
  ],
  About: [
    { label: 'Our Story', to: '/about' },
    { label: 'Contact Us', to: '/contact' },
    { label: 'FAQs', to: '/faq' },
  ],
'Customer Care': [
    { label: 'Shipping & Delivery', to: '/shipping' },
    { label: 'Returns & Refunds', to: '/returns' },
    { label: 'Privacy Policy', to: '/privacy' },
    { label: 'Terms & Conditions', to: '/terms' },
  ],
};

export function Footer() {
  const { notify } = useStore();
  const { navigate } = useRouter();
  const [email, setEmail] = useState('');

  const subscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      notify('Please enter a valid email address.');
      return;
    }
    notify('You are on the list. Welcome to NOVIQ.');
    setEmail('');
  };

  return (
    <footer className="bg-espresso-950 text-ivory-200 mt-24">
      {/* Newsletter */}
      <div className="border-b border-espresso-800">
        <div className="container-page py-16 text-center">
          <p className="eyebrow text-gold-400 mb-3">Stay in touch</p>
          <h2 className="font-serif text-3xl md:text-4xl text-ivory-50 mb-3">A Little Beauty in Your Inbox.</h2>
          <p className="text-sm text-ivory-200/70 max-w-md mx-auto mb-6">
            New launches, beauty rituals, and exclusive offers — written thoughtfully, sent occasionally.
          </p>
          <form onSubmit={subscribe} className="max-w-md mx-auto flex gap-2">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email address"
              aria-label="Email address"
              className="flex-1 bg-transparent border border-espresso-800 px-4 py-3 text-sm text-ivory-50 placeholder:text-ivory-200/40 focus:outline-none focus:border-gold-500 transition-colors"
            />
            <button type="submit" className="bg-ivory-50 text-espresso-900 px-6 py-3 text-[0.7rem] tracking-[0.2em] uppercase font-medium hover:bg-gold-500 transition-colors">
              Subscribe
            </button>
          </form>
        </div>
      </div>

      {/* Links */}
      <div className="container-page py-14 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8">
        <div className="col-span-2 md:col-span-2">
          <Link to="/" className="font-serif text-2xl tracking-[0.3em] text-ivory-50 font-semibold pl-[0.3em]">NOVIQ</Link>
          <p className="text-xs tracking-[0.3em] uppercase text-gold-400 mt-1">Cosmetics</p>
          <p className="mt-5 text-sm text-ivory-200/70 max-w-xs">
            Your Beauty. Your Signature. Thoughtfully curated makeup and skincare for everyday confidence.
          </p>
          <div className="flex items-center gap-4 mt-6">
            <a href="#" aria-label="Instagram" className="text-ivory-200/70 hover:text-gold-400 transition-colors"><Instagram size={18} /></a>
            <a href="#" aria-label="Facebook" className="text-ivory-200/70 hover:text-gold-400 transition-colors"><Facebook size={18} /></a>
            <a href="#" aria-label="Youtube" className="text-ivory-200/70 hover:text-gold-400 transition-colors"><Youtube size={18} /></a>
          </div>
        </div>

        {Object.entries(FOOTER_LINKS).map(([heading, links]) => (
          <div key={heading}>
            <h4 className="text-[0.65rem] tracking-[0.25em] uppercase text-gold-400 font-medium mb-4">{heading}</h4>
            <ul className="flex flex-col gap-2.5">
              {links.map((l) => (
                <li key={l.label}>
                  <button onClick={() => navigate(l.to)} className="text-sm text-ivory-200/70 hover:text-ivory-50 transition-colors text-left">
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}

        <div>
          <h4 className="text-[0.65rem] tracking-[0.25em] uppercase text-gold-400 font-medium mb-4">Support</h4>
          <ul className="flex flex-col gap-2.5 text-sm text-ivory-200/70">
            <li className="flex items-start gap-2"><Mail size={14} className="mt-0.5 shrink-0" /> care@noviq.cosmetics</li>
            <li className="flex items-start gap-2"><Phone size={14} className="mt-0.5 shrink-0" /> +92 300 1234567</li>
            <li className="flex items-start gap-2"><MapPin size={14} className="mt-0.5 shrink-0" /> Lahore, Pakistan</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-espresso-800">
        <div className="container-page py-5 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-ivory-200/50">
          <p>© 2026 NOVIQ COSMETICS. All rights reserved.</p>
          <p className="tracking-[0.15em] uppercase text-[0.6rem]">Your Beauty. Your Signature.</p>
        </div>
      </div>
    </footer>
  );
}
