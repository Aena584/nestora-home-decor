import { useEffect, useState, useCallback } from 'react';

export type Route = {
  path: string;
  query: Record<string, string>;
};

function parseHash(): Route {
  const hash = window.location.hash.slice(1) || '/';
  const [path, qs = ''] = hash.split('?');
  const query: Record<string, string> = {};
  new URLSearchParams(qs).forEach((v, k) => { query[k] = v; });
  return { path, query };
}

export function useRouter() {
  const [route, setRoute] = useState<Route>(parseHash);

  useEffect(() => {
    const onChange = () => {
      setRoute(parseHash());
      window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    };
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);

  const navigate = useCallback((to: string) => {
    window.location.hash = to.startsWith('#') ? to : to;
  }, []);

  return { route, navigate };
}

export function Link({ to, children, className, onClick, ...rest }: { to: string; children: React.ReactNode; className?: string; onClick?: () => void } & Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, 'href' | 'onClick'>) {
  const href = '#' + to;
  return (
    <a
      href={href}
      className={className}
      onClick={onClick}
      {...rest}
    >
      {children}
    </a>
  );
}
